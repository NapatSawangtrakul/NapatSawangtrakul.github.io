<?php
session_start();
require 'db_connect.php';
?>
<!doctype html>
<html lang="th">
<head>
    <meta charset="utf-8">
    <title>User</title>
    <link rel="stylesheet" href="factory.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-4">
        <?php include('message.php'); ?>
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <h4>ยินดีต้อนรับเจ้าหน้าที่ <?php echo $_SESSION["username"]; ?> </h4>
                        <h4>รายละเอียดบัญชี
                            <a href="User/user-create.php" class="btn btn-primary float-end">เพิ่มบัญชี</a>
                            <a href="logout.php" class="btn btn-danger float-end">ออกจากระบบ</a>
                        </h4>
                    </div>
                    <div class="col-md-7">
                        <form action="" method="GET" id="searchForm">
                            <div class="input-group mb-3">
                                <input type="text" class="form-control border border-secondary" placeholder="ค้นหาตามชื่อผู้ใช้" name="username" id="searchInput" aria-describedby="button-addon2">
                                    <select class="form-select" name="position" id="positionSelect">
                                        <option value="">ทุกตำแหน่ง</option>
                                        <option value="A">Admin</option>
                                        <option value="P">Procurement</option>
                                        <option value="S">Sales Department</option>
                                    </select>
                                    <select class="form-select" name="status" id="statusSelect">
                                        <option value="">ทุกสถานะ</option>
                                        <option value="0">Active</option>
                                        <option value="1">Inactive</option>
                                    </select>
                                <button class="btn btn-outline-secondary" type="submit" id="searchButton">ค้นหา</button>
                                <button class="btn btn-outline-secondary" type="button" id="resetButton" onclick="resetTable()">รีเซ็ต</button>
                            </div>
                        </form>
                    </div>
<div class="card-body">
                        <table id="userTable" class="table table-bordered table-striped">
                            <thead>
                                <tr class="text-center align-middle">
                                    <th>ลำดับที่</th>
                                    <th>ชื่อบัญชีผู้ใช้งาน</th>
                                    <th>ชื่อผู้ใช้</th>
                                    <th>ตำแหน่ง</th>
                                    <th>สถานะ</th>
                                    <th></th> 
                                </tr>
                            </thead>
                            <tbody>
                                <?php 
                                $i = 1; 
                                $query = "SELECT * FROM login";
                                $query_run = mysqli_query($db_conn, $query);

                                if(mysqli_num_rows($query_run) > 0) {
                                    while($useraccount = mysqli_fetch_assoc($query_run)) {
                                        if ($useraccount['status'] == 0) {
                                ?>
                                <tr class="align-middle">
                                    <td><?= $i; ?></td> 
                                    <td><?= $useraccount['user_id']; ?></td>
                                    <td><?= $useraccount['name']; ?></td>
                                    <td>
                                        <?php
                                        if ($useraccount['user'] == 'A') {
                                            echo "Admin";
                                        } elseif ($useraccount['user'] == 'P') {
                                            echo "Procurement";
                                        } elseif ($useraccount['user'] == 'S') {
                                            echo "Sales Department";
                                        }
                                        ?>
                                    </td>
                                    <td>
                                        <?php
                                        if ($useraccount['status'] == 0) {
                                            echo "Active";
                                        } elseif ($useraccount['status'] == 1) {
                                            echo "Inactive";
                                        }
                                        ?>
                                    </td>
                                    <td class="text-center align-middle">
                                    <div class="d-flex align-items-center">
                                        <?php if ($useraccount['status'] == 0): ?>
                                            <form action="User/user-submit.php" method="POST" class="d-inline">
                                                <button type="submit" name="active_user" value="<?= $useraccount['id']; ?>" class="btn btn-primary btn-sm hidden-btn">active</button>
                                            </form>
                                        <?php elseif ($useraccount['status'] == 1): ?>
                                            <form action="User/user-submit.php" method="POST" class="d-inline">
                                                <button type="submit" name="active_user" value="<?= $useraccount['id']; ?>" class="btn btn-primary btn-sm">active</button>
                                            </form>
                                        <?php endif; ?>
                                        <!-- <a href="User/useradmin-edit.php?id=<?= $useraccount['id']; ?>" class="btn btn-success btn-sm">Edit</a> -->
                                        <?php if ($useraccount['status'] == 0 ): ?>
                                            <form action="User/user-submit.php" method="POST" class="d-inline">
                                                <button type="submit" name="delete_user" value="<?= $useraccount['id']; ?>" class="btn btn-danger btn-sm">Delete</button>
                                            </form>
                                        <?php elseif ($useraccount['status'] == 1): ?>
                                            <form action="User/user-submit.php" method="POST" class="d-inline">
                                                <button type="submit" name="delete_user" value="<?= $useraccount['id']; ?>" class="btn btn-danger btn-sm hidden-btn">Delete</button>
                                            </form>
                                        <?php endif; ?>
                                    </div>
                                    </td>
                                </tr>
                                <?php
                                    $i++; 
                                    }
                                }
                            }
                                else
                                {
                                    echo "<tr><td colspan='6'><h5>ไม่พบรายการ</h5></td></tr>";
                                }
                                ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <style>
    .hidden-btn {
        display: none;
    }
    </style>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
document.addEventListener("DOMContentLoaded", function () {
    const searchForm = document.getElementById('searchForm');
    const searchInput = document.getElementById('searchInput');
    const positionSelect = document.getElementById('positionSelect');
    const statusSelect = document.getElementById('statusSelect');
    const searchButton = document.getElementById('searchButton');
    const resetButton = document.getElementById('resetButton');
    const tableBody = document.querySelector("tbody");

    searchForm.addEventListener('submit', function (event) {
        event.preventDefault();
        const searchValue = searchInput.value.trim();
        const positionValue = positionSelect.value;
        const statusValue = statusSelect.value;
        fetch(`User/user-search.php?nameId=${searchValue}&position=${positionValue}&status=${statusValue}`)
            .then(response => response.text())
            .then(data => {
                document.getElementById('userTable').innerHTML = data;
            })
            .catch(error => console.error('เกิดข้อผิดพลาดในการดึงข้อมูล:', error));
    });

    resetButton.addEventListener("click", function() {
            window.location.href = "user-main.php";
        });

    resetButton.addEventListener("click", resetSearch);
});
</script>
</body>
</html>
