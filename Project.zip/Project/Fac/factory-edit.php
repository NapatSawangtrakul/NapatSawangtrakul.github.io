<?php
session_start();
require '../db_connect.php';
?>

<!doctype html>
<html lang="th">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/factory.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <title>ตั้งค่าโรงงาน</title>
</head>
<body>
    <div class="container-fluid mt-4 custom-container">
        <?php include('../message.php'); ?>
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <h4>แก้ไขข้อมูลโรงงาน
                            <a href="../factory-main.php" class="btn btn-danger float-end">กลับหน้าหลัก</a>
                        </h4>
                    </div>
                    <div class="card-body">
                        <?php
                        if (isset($_GET['id'])) {
                            $factory_id = mysqli_real_escape_string($db_conn, $_GET['id']);
                            $query = "SELECT * FROM factory WHERE id='$factory_id'";
                            $query_run = mysqli_query($db_conn, $query);

                            if (mysqli_num_rows($query_run) > 0) {
                                $factory = mysqli_fetch_array($query_run);
                                ?>
                                <form action="factory-submit.php" method="POST">
                                    <input type="hidden" name="factory_id" value="<?= $factory['id']; ?>">
                                    
                                    <div class="mb-3">
                                        <label for="namefac" class="form-label">ชื่อโรงงาน</label>
                                        <input type="text" name="namefac" value="<?= $factory['Name']; ?>" class="form-control border border-secondary" required>
                                    </div>
                                    <div class="mb-3">
                                        <label for="locationfac" class="form-label">ที่อยู่โรงงาน</label>
                                        <textarea name="locationfac" rows="4" class="form-control border border-secondary" required><?= $factory['Location']; ?></textarea>
                                    </div>
                                    <div class="mb-3">
                                        <label for="contactfac" class="form-label">ผู้ที่ติดต่อ</label>
                                        <input type="text" name="contactfac" value="<?= $factory['Contact']; ?>" class="form-control border border-secondary" required>
                                    </div>
                                    <div class="mb-3">
                                        <label for="phonefac" class="form-label">เบอร์ติดต่อ</label>
                                        <input type="text" name="phonefac" value="<?= $factory['Phone']; ?>" class="form-control border border-secondary" required>
                                    </div>
                                    <div class="mb-3">
                                        <label for="linetoken" class="form-label">Linetoken</label>
                                        <input type="text" name="linetoken" value="<?= $factory['Linetoken']; ?>" class="form-control border border-secondary">
                                    </div>
                                    <div class="mb-3">
                                        <label for="annotaionfac" class="form-label">คำอธิบายประกอบ</label>
                                        <input type="text" name="annotaionfac" value="<?= $factory['Annotaion']; ?>" class="form-control border border-secondary">
                                    </div>
                                    <div class="mb-3">
                                        <button type="submit" name="update_factory" class="btn btn-primary">บันทึก</button>
                                    </div>
                                </form>
                                <?php
                            } else {
                                echo "<h4>ไม่พบรายการ</h4>";
                            }
                        }
                        ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
<style>
    .custom-container {
        margin-left: 100px;
        margin-right: 100px;
    }
</style>
</body>
</html>
