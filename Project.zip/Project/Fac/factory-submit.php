<?php
session_start();
require '../db_connect.php';

if(isset($_POST['active_factory'])) {
    $factory_id = mysqli_real_escape_string($db_conn, $_POST['active_factory']);

    $query = "UPDATE factory SET status = 1 WHERE id='$factory_id'";
    $query_run = mysqli_query($db_conn, $query);

    if($query_run)
    {
        $_SESSION['message'] = "ปรับปรุงโรงงานสำเร็จ";
        header("Location: ../factory-main.php");
        exit(0);
    } 
    else
    {
        $_SESSION['message'] = "ปรับปรุงโรงงานไม่สำเร็จ";
        header("Location: ../factory-main.php");
        exit(0);
    }
}

if (isset($_POST['delete_factory'])) {
    $factory_id = mysqli_real_escape_string($db_conn, $_POST['delete_factory']);

    $query = "UPDATE factory SET status = 0 WHERE id='$factory_id'";
    $query_run = mysqli_query($db_conn, $query);

    if($query_run) {
        $_SESSION['message'] = "ปรับปรุงโรงงานสำเร็จ";
        header("Location: ../factory-main.php");
        exit(0);
    } else {
        $_SESSION['message'] = "ปรับปรุงโรงงานไม่สำเร็จ";
        header("Location: ../factory-main.php");
        exit(0);
    }
}

if(isset($_POST['update_factory']))
{
    $factory_id = mysqli_real_escape_string($db_conn, $_POST['factory_id']);
    $name = mysqli_real_escape_string($db_conn, $_POST['namefac']);
    $location = mysqli_real_escape_string($db_conn, $_POST['locationfac']);
    $contact = mysqli_real_escape_string($db_conn, $_POST['contactfac']);
    $phone = mysqli_real_escape_string($db_conn, $_POST['phonefac']);
    $linetoken = mysqli_real_escape_string($db_conn, $_POST['linetoken']);
    $annotaion = mysqli_real_escape_string($db_conn, $_POST['annotaionfac']);

    $query = "UPDATE factory SET Name='$name', Location='$location', Contact='$contact', Phone='$phone', Linetoken='$linetoken', Annotaion='$annotaion' WHERE id='$factory_id'";
    $query_run = mysqli_query($db_conn, $query);

    if($query_run)
    {
        $_SESSION['message'] = "ปรับปรุงโรงงานสำเร็จ";
        header("Location: ../factory-main.php");
        exit(0);
    }
    else
    {
        $_SESSION['message'] = "ปรับปรุงโรงงานไม่สำเร็จ";
        header("Location: ../factory-main.php");
        exit(0);
    }

}

if (isset($_POST['save_factory'])) {
    $name = mysqli_real_escape_string($db_conn, $_POST['namefac']);
    $location = mysqli_real_escape_string($db_conn, $_POST['locationfac']);
    $contact = mysqli_real_escape_string($db_conn, $_POST['contactfac']);
    $phone = mysqli_real_escape_string($db_conn, $_POST['phonefac']);
    $linetoken = mysqli_real_escape_string($db_conn, $_POST['linetoken']);
    $annotaion = mysqli_real_escape_string($db_conn, $_POST['annotaionfac']);

    $query = "INSERT INTO factory (Name, Location, Contact, Phone, Linetoken, Annotaion) VALUES ('$name','$location','$contact','$phone', '$linetoken', '$annotaion')";

    $query_run = mysqli_query($db_conn, $query);
    if ($query_run) {
        $_SESSION['message'] = "เพิ่มโรงงานสำเร็จ";
        header("Location: ../factory-main.php");
        exit(0);
    } else {
        $_SESSION['message'] = "เพิ่มโรงงานไม่สำเร็จ";
        header("Location: ../factory-main.php");
        exit(0);
    }
}
?>