<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/factory.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <title>เพิ่มโรงงาน</title>
</head>
<body>
    <div class="container-fluid mt-4 custom-container">
        <?php include('../message.php'); ?>
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <h4>เพิ่มโรงงาน
                            <a href="../factory-main.php" class="btn btn-danger float-end">กลับหน้าหลัก</a>
                        </h4>
                    </div>
                    <div class="card-body">
                        <form action="factory-submit.php" id="FacForm" method="POST" novalidate>
                            <div class="mb-3">
                                <label for="namefac" class="form-label">ชื่อโรงงาน <span style="color: red;">*</span></label>
                                <input type="text" name="namefac" class="form-control border border-secondary" required>
                                <div class="invalid-feedback">
                                    กรุณากรอกชื่อโรงงาน
                                </div>
                            </div>
                            <div class="mb-3">
                                <label for="locationfac" class="form-label">สถานที่โรงงาน <span style="color: red;">*</span></label>
                                <textarea name="locationfac" rows="4" cols="50" class="form-control border border-secondary" required></textarea>
                                <div class="invalid-feedback">
                                    กรุณากรอกสถานที่โรงงาน
                                </div>
                            </div>
                            <div class="mb-3">
                                <label for="contactfac" class="form-label">ผู้ที่ติดต่อ <span style="color: red;">*</span></label>
                                <input type="text" name="contactfac" class="form-control border border-secondary" required>
                                <div class="invalid-feedback">
                                    กรุณากรอกผู้ที่ติดต่อ
                                </div>
                            </div>
                            <div class="mb-3">
                                <label for="phonefac" class="form-label">เบอร์ติดต่อ <span style="color: red;">*</span></label>
                                <input type="text" name="phonefac" class="form-control border border-secondary" required>
                                <div class="invalid-feedback">
                                    กรุณากรอกเบอร์ติดต่อ
                                </div>
                            </div>
                            <div class="mb-3">
                                <label for="linetoken" class="form-label">Linetoken</label>
                                <input type="text" name="linetoken" class="form-control border border-secondary">
                            </div>
                            <div class="mb-3">
                                <label for="annotaionfac" class="form-label">คำอธิบายประกอบ</label>
                                <input type="text" name="annotaionfac" class="form-control border border-secondary">
                            </div>
                            <div class="mb-3">
                                <button type="submit" name="save_factory" class="btn btn-primary">บันทึก</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
    document.addEventListener('DOMContentLoaded', function() {
        const form = document.getElementById('FacForm');

        form.addEventListener('submit', function(event) {
            if (!form.checkValidity()) {
                event.preventDefault();
                event.stopPropagation();
            }
            form.classList.add('was-validated');
        }, false);
    });
    </script>
    <style>
    .custom-container {
        margin-left: 100px;
        margin-right: 100px;
    }
    </style>
</body>
</html>
