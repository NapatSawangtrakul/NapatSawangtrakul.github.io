<?php
session_start();
require('../db_connect.php');


if(isset($_POST['delete_po'])) {
    $poDelete = mysqli_real_escape_string($db_conn, $_POST['delete_po']);

    $deleteQuery = "UPDATE addpo SET status = 7 WHERE id = ?";
    $delete = $db_conn->prepare($deleteQuery);

    if ($delete) {
        $delete->bind_param("i", $poDelete);
        $delete->execute();
        $delete->close();

        $_SESSION['message'] = "ปรับปรุงสำเร็จ";
        header("Location: ../po-main.php");
        exit(0);
    } else {
        $_SESSION['message'] = "ปรับปรุงไม่สำเร็จ";
        header("Location: ../po-main.php");
        exit(0);
    }
}
$db_conn->close();
?>
