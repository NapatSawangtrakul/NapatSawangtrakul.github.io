<?php
session_start();
require '../db_connect.php';

if (isset($_GET['id'])) {
    $id = mysqli_real_escape_string($db_conn, $_GET['id']);

    $checkStatusQuery = "SELECT status, namefac, po FROM addpo WHERE id = ?";
    $checkStatusStmt = $db_conn->prepare($checkStatusQuery);
    $checkStatusStmt->bind_param("i", $id);
    $checkStatusStmt->execute();
    $checkStatusStmt->bind_result($currentStatus, $namefac, $po);
    $checkStatusStmt->fetch();
    $checkStatusStmt->close();

    if ($currentStatus == 0) {
        $updateQuery = "UPDATE addpo SET status = '1', orderdate = NOW() WHERE id = ?";
        $updateStmt = $db_conn->prepare($updateQuery);
        $updateStmt->bind_param("i", $id);
        $updateStmt->execute();
        $updateStmt->close();

        $lineTokenQuery = "SELECT LineToken FROM factory WHERE id = ?";
        $lineTokenStmt = $db_conn->prepare($lineTokenQuery);
        $lineTokenStmt->bind_param("i", $namefac);
        $lineTokenStmt->execute();
        $lineTokenStmt->bind_result($lineToken);
        $lineTokenStmt->fetch();
        $lineTokenStmt->close();

        if ($lineToken) {
            $sMessage = "มีใบสั่งซื้อมาใหม่ " . $po;
            $chOne = curl_init(); 
            curl_setopt($chOne, CURLOPT_URL, "https://notify-api.line.me/api/notify"); 
            curl_setopt($chOne, CURLOPT_SSL_VERIFYHOST, 0); 
            curl_setopt($chOne, CURLOPT_SSL_VERIFYPEER, 0); 
            curl_setopt($chOne, CURLOPT_POST, 1); 
            curl_setopt($chOne, CURLOPT_POSTFIELDS, "message=".$sMessage); 
            $headers = array('Content-type: application/x-www-form-urlencoded', 'Authorization: Bearer '.$lineToken.'', );
            curl_setopt($chOne, CURLOPT_HTTPHEADER, $headers); 
            curl_setopt($chOne, CURLOPT_RETURNTRANSFER, 1); 
            $result = curl_exec($chOne);
            curl_close($chOne);
        }
    }
} else {
    $_SESSION['message'] = "ไม่พบ PO";
}

header("Location: ../po-view.php");
exit();
?>
