<?php
require('../db_connect.php');

$dateFrom = $_GET['date_from'];
$dateTo = $_GET['date_to'];
$customer = $_GET['namecustomer'];
$status = $_GET['status'];

$results_per_page = 10;

if (!isset($_GET['page'])) {
    $page = 1;
} else {
    $page = $_GET['page'];
}

$this_page_first_result = ($page - 1) * $results_per_page;

$condition = "1";
if (!empty($dateFrom) && !empty($dateTo)) {
    $condition .= " AND addpo.date_created BETWEEN '$dateFrom' AND '$dateTo'";
}
if (!empty($customer)) {
    $condition .= " AND (addpo.namecustomer LIKE '%$customer%' OR addpo.pr LIKE '%$customer%' OR addpo.po LIKE '%$customer%' OR factory.Name LIKE '%$customer%')";
}
if ($status !== '') {
    $condition .= " AND addpo.status = $status";
}

$query = "SELECT addpo.*, factory.Name AS factory_name FROM addpo 
          LEFT JOIN factory ON addpo.namefac = factory.id 
          WHERE $condition ORDER BY po DESC LIMIT $this_page_first_result, $results_per_page";

$query_run = mysqli_query($db_conn, $query);

$sql = "SELECT COUNT(*) AS total FROM addpo";
$result = mysqli_query($db_conn, $sql);
$row = mysqli_fetch_assoc($result);
$total_pages = ceil($row["total"] / $results_per_page);

$i = 1;
if (mysqli_num_rows($query_run) > 0) {
    while ($purchase_order = mysqli_fetch_assoc($query_run)) {
        echo '<tr class="align-middle">';
        echo '<td>' . $i . '</td>';
        echo '<td>' . date("d/m/Y", strtotime($purchase_order['date_created'])) . '</td>';
        echo '<td>' . $purchase_order['pr'] . '</td>';
        echo '<td>' . $purchase_order['po'] . '</td>';
        echo '<td>' . $purchase_order['namecustomer'] . '</td>';
        $phone = $purchase_order['phone'];
        if (strlen($phone) == 10) {
            $formattedPhone = substr($phone, 0, 3) . '-' . substr($phone, 3, 3) . '-' . substr($phone, 6);
        } else {
            $formattedPhone = $phone;
        }
        echo '<td>' . $formattedPhone . '</td>';

        echo '<td>' . $purchase_order['factory_name'] . '</td>';
        echo '<td>';
        if ($purchase_order['status'] == 0) {
            echo '<span style="color:#080808;">รอดำเนินการ</span>';
        } elseif ($purchase_order['status'] == 1) {
            echo '<span style="color:#080808;">กำลังเตรียมส่ง</span>';
        } elseif ($purchase_order['status'] == 2) {
            echo '<span style="color:#080808;">สินค้าครบ</span>';
        } elseif ($purchase_order['status'] == 3) {
            echo '<span style="color:#080808;">สินค้ายังไม่ครบ</span>';
        } elseif ($purchase_order['status'] == 7) {
            echo '<span style="color:#080808;">ยกเลิกดำเนินการ</span>';
        }
        echo '</td>';
        echo '<td class="text-center align-middle">
            <div class="d-flex align-items-center">
                <a href="PO/po-view.php?id=' . $purchase_order['id'] . '" class="btn btn-info btn-sm">View</a>';

        if ($purchase_order['status'] == 1 || $purchase_order['status'] == 3) {
            echo '<a href="PO/po-edit.php?id=' . $purchase_order['id'] . '" class="btn btn-success btn-sm">Receive</a>';
        } else {
            echo '<a href="PO/po-edit.php?id=' . $purchase_order['id'] . '" class="btn btn-success btn-sm hidden-btn">Receive</a>';
        }

        echo '<form action="PO/po-submit.php" method="POST" class="d-inline">';
        if ($purchase_order['status'] != 2) {
            echo '<button type="submit" name="delete_po" value="' . $purchase_order['id'] . '" class="btn btn-danger btn-sm">Delete</button>';
        } elseif ($purchase_order['status'] == 2 && $purchase_order['status'] == 7) {
            echo '<button type="submit" name="delete_po" value="' . $purchase_order['id'] . '" class="btn btn-danger btn-sm hidden-btn">Delete</button>';
        }
        echo ' </form>  ';     

        echo '</div>';
        echo '</td>';
        echo '</tr>';

        $i++;
    }
} else {
    echo "<tr><td colspan='9' class='text-center'>ไม่พบรายการ</td></tr>";
}

mysqli_close($db_conn);
?>
