<?php
session_start();
require '../db_connect.php';

function getStatus($item_id) {
    global $db_conn, $po;
    $status = 0; 

    $getStatusQuery = "SELECT status FROM itemlistpo WHERE pr_id = ? AND idpro_id = ?";
    $getStatusStmt = $db_conn->prepare($getStatusQuery);
    if ($getStatusStmt === false) {
        die('Error preparing statement');
    }
    $getStatusStmt->bind_param("ss", $po['pr'], $item_id);
    $getStatusStmt->execute();
    $getStatusStmt->bind_result($status);
    $getStatusStmt->fetch();
    $getStatusStmt->close();
    return $status;
}

if (isset($_GET['id'])) {
    $id = mysqli_real_escape_string($db_conn, $_GET['id']);
    $query = "SELECT * FROM addpo WHERE id = ?";
    $stmt = $db_conn->prepare($query);
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows == 1) {
        $po = $result->fetch_assoc();
    } else {
        $_SESSION['message'] = "ไม่พบ PO";
        header("Location: ../po-main.php");
        exit();
    }
} else {
    $_SESSION['message'] = "ไม่พบ PO";
    header("Location: ../po-main.php");
    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $received_items = $_POST['received_items'] ?? [];

    $itemListInsQuery = "SELECT idpro_id FROM itemlistpo WHERE pr_id = ? AND po_id = ?";
    $itemListInsStmt = $db_conn->prepare($itemListInsQuery);
    $itemListInsStmt->bind_param("ss", $po['pr'], $po['po']);
    $itemListInsStmt->execute();
    $itemListInsResult = $itemListInsStmt->get_result();

    while ($item = $itemListInsResult->fetch_assoc()) {
        $item_id = $item['idpro_id'];
        $received_status = in_array($item_id, $received_items) ? 1 : 0;
        updateStatus($item_id, $received_status);
    }

    if (!checkAllItemsReceived()) {
        updateAddPoStatus(3);
    } else {
        updateAddPoStatus(2);
    }

    header("Location: ../po-main.php");
    exit();
}

function updateStatus($item_id, $received_status) {
    global $db_conn, $po;

    $updateStatusQuery = "UPDATE itemlistpo SET status = ?, date_received = IFNULL(date_received, NOW()) WHERE pr_id = ? AND po_id = ? AND idpro_id = ?";
    $updateStatusStmt = $db_conn->prepare($updateStatusQuery);

    if ($updateStatusStmt === false) {
        die('เกิดข้อผิดพลาด');
    }

    $updateStatusStmt->bind_param("isss", $received_status, $po['pr'], $po['po'], $item_id);

    if (!$updateStatusStmt->execute()) {
        echo "เกิดข้อผิดพลาด: (" . $updateStatusStmt->errno . ") " . $updateStatusStmt->error;
    }
    $updateStatusStmt->close();

    $getOrderDateQuery = "SELECT orderdate FROM addpo WHERE pr = ? AND po = ?";
    $getOrderDateStmt = $db_conn->prepare($getOrderDateQuery);
    
    if ($getOrderDateStmt === false) {
        die('เกิดข้อผิดพลาด');
    }
    
    $getOrderDateStmt->bind_param("ss", $po['pr'], $po['po']);
    $getOrderDateStmt->execute();
    $getOrderDateStmt->bind_result($orderdate);
    $getOrderDateStmt->fetch();
    $getOrderDateStmt->close();

    $getDateReceivedQuery = "SELECT date_received FROM itemlistpo WHERE pr_id = ? AND po_id = ? AND idpro_id = ?";
    $getDateReceivedStmt = $db_conn->prepare($getDateReceivedQuery);
    
    if ($getDateReceivedStmt === false) {
        die('เกิดข้อผิดพลาด');
    }
    
    $getDateReceivedStmt->bind_param("sss", $po['pr'], $po['po'], $item_id);
    $getDateReceivedStmt->execute();
    $getDateReceivedStmt->bind_result($date_received);
    $getDateReceivedStmt->fetch();
    $getDateReceivedStmt->close();

    if ($date_received && $orderdate) {
        $order_date = new DateTime($orderdate);
        $received_date = new DateTime($date_received);
        $interval = $order_date->diff($received_date);

        if ($interval->days > 15) {
            $delayed_status = 1;
        } else {
            $delayed_status = 0;
        }

        $updateDelayedStatusQuery = "UPDATE itemlistpo SET delayed_status = ? WHERE pr_id = ? AND po_id = ? AND idpro_id = ?";
        $updateDelayedStatusStmt = $db_conn->prepare($updateDelayedStatusQuery);

        if ($updateDelayedStatusStmt === false) {
            die('เกิดข้อผิดพลาด');
        }

        $updateDelayedStatusStmt->bind_param("isss", $delayed_status, $po['pr'], $po['po'], $item_id);

        if (!$updateDelayedStatusStmt->execute()) {
            echo "เกิดข้อผิดพลาด: (" . $updateDelayedStatusStmt->errno . ") " . $updateDelayedStatusStmt->error;
        }
        $updateDelayedStatusStmt->close();
    }
}


function checkAllItemsReceived() {
    global $db_conn, $po;

    $count = 0;

    $checkAllItemsQuery = "SELECT COUNT(*) FROM itemlistpo WHERE pr_id = ? AND po_id = ? AND status = 0";
    $checkAllItemsStmt = $db_conn->prepare($checkAllItemsQuery);

    if ($checkAllItemsStmt === false) {
        die('เกิดข้อผิดพลาด');
    }

    $checkAllItemsStmt->bind_param("ss", $po['pr'], $po['po']);
    $checkAllItemsStmt->execute();
    $checkAllItemsStmt->bind_result($count);
    $checkAllItemsStmt->fetch();
    $checkAllItemsStmt->close();

    return $count == 0;
}

function updateAddPoStatus($status) {
    global $db_conn, $po;

    $updateAddPoStatusQuery = "UPDATE addpo SET status = ? WHERE pr = ? AND po = ?";
    $updateAddPoStatusStmt = $db_conn->prepare($updateAddPoStatusQuery);

    if ($updateAddPoStatusStmt === false) {
        die('เกิดข้อผิดพลาด');
    }

    $updateAddPoStatusStmt->bind_param("iss", $status, $po['pr'], $po['po']);

    if (!$updateAddPoStatusStmt->execute()) {
        echo "เกิดข้อผิดพลาด: (" . $updateAddPoStatusStmt->errno . ") " . $updateAddPoStatusStmt->error;
    }

    $updateAddPoStatusStmt->close();
}
?>

<!doctype html>
<html lang="th">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/factory.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <title>รายละเอียดใบสั่งซื้อของโรงงาน</title>
</head>
<body>
    <div class="container-fluid mt-4 custom-container">
        <?php include('../message.php'); ?>
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <h4>รายละเอียดใบสั่งซื้อของโรงงาน
                            <a href="../po-main.php" class="btn btn-danger float-end">กลับหน้าหลัก</a>
                        </h4>
                    </div>

                    <div class="card-body">
                    <form action="po-edit.php?id=<?= $id ?>" method="POST">
                    <?php
                            $query = mysqli_query($db_conn, "SELECT * FROM mf");
                            while ($row = mysqli_fetch_array($query)) {
                            ?>
                                <div class="form">
                                    <table class="table">
                                        <tr>
                                            <td>
                                                <h3><?php echo $row['nameTH']; ?></h3>
                                                <h3><?php echo $row['nameEN']; ?></h3>
                                                <h5><?php echo $row['locationTH']; ?></h5>
                                                <h5><?php echo $row['locationEN']; ?></h5>
                                                <h5>Tel : <?php echo $row['phone']; ?></h5>
                                            </td>
                                            <td>
                                                <h3>Purchase Order</h3>
                                                <h5 class="mt-4">เลขที่เอกสาร PR : <?= $po['pr']; ?></h5>
                                                <h5>เลขที่เอกสาร PO : <?= $po['po']; ?></h5>
                                                <h5>วันที่ : <?= date('d/m/Y', strtotime($po['date_created'])); ?></h5>
                                                <h5 for="namecustomer" class="form-label">ชื่อลูกค้า : <?= $po['namecustomer']; ?></h5>
                                                <h5 for="namecustomer" class="form-label print-hidden">เบอร์โทรศัพท์ลูกค้า : <?= $po['phone']; ?></h5>
                                                <h5 for="namefac" class="form-label">ชื่อโรงงาน : <?php
                                                $namefacNumber = $po['namefac'];
                                                $factoryQuery = "SELECT Name, Location FROM factory WHERE id = ?";
                                                $factoryStmt = $db_conn->prepare($factoryQuery);
                                                $factoryStmt->bind_param("i", $namefacNumber);
                                                $factoryStmt->execute();
                                                $factoryResult = $factoryStmt->get_result();

                                                if ($factoryResult->num_rows === 1) {
                                                    $factoryData = $factoryResult->fetch_assoc();
                                                    echo $factoryData['Name'];
                                                    echo "<h5>" . $factoryData['Location'] . "</h5>";
                                                } else {
                                                    echo "ไม่พบโรงงาน";
                                                }
                                            ?></h5>
                                            </td>
                                        </tr>
                                    </table>
                                </div>
                            <?php
                            }
                            ?>
                        <table class="table table-bordered">
                            <thead>
                                <tr class="text-center">
                                    <th>รหัสสินค้า-ชื่อสินค้า</th>
                                    <th>จำนวนสินค้า(แผ่น)</th>
                                    <th>เลือกสินค้าที่รับ</th>
                                </tr>
                            </thead>
                                <tbody>
                                    <?php
                                    $poNumber = $po['pr'];
                                    $poId = $po['po']; 
            
                                    $itemListInsQuery = "SELECT * FROM itemlistpo WHERE pr_id = ? AND po_id = ?";
                                    $itemListInsStmt = $db_conn->prepare($itemListInsQuery);
                                    $itemListInsStmt->bind_param("ss", $poNumber, $poId);
                                    $itemListInsStmt->execute();
                                    $itemListInsResult = $itemListInsStmt->get_result();
            
                                    if ($itemListInsResult->num_rows > 0) {
                                        while ($item = $itemListInsResult->fetch_assoc()) {
                                    ?>
                                        <tr>
                                            <td><?= $item['idpro_id']; ?> - <?= $item['namepro']; ?></td>
                                            <td class="text-center"><?= $item['quantity']; ?></td>
                                            <td class="text-center align-middle">
                                                <input type="checkbox" name="received_items[]" value="<?= $item['idpro_id']; ?>" <?= $item['status'] == 1 ? 'checked' : ''; ?>>
                                            </td>
                                        </tr>
                                    <?php
                                        }
                                    } else {
                                        echo "<tr><td colspan='3'>ไม่พบรายการสินค้า</td></tr>";
                                    }
                                    ?>
                                </tbody>
                            </table>
                            <input type="submit" class="btn btn-info" value="บันทึกการรับสินค้า">
                    </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
<style>
.custom-container {
            margin-left: 100px;
            margin-right: 100px;
        }
</style>
</body>
</html>
