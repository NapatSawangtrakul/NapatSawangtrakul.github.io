<?php
session_start();
require '../db_connect.php';

$updateStatusQuery = "UPDATE addprfac SET status = 4 WHERE id = ?";
$updateStatusStmt = $db_conn->prepare($updateStatusQuery);

if (isset($_POST['Order_po'])) {
    $prfacId = $_POST['Order_po'];

    $fetchPrfacQuery = "SELECT * FROM addprfac WHERE id = ?";
    $fetchPrfacStmt = $db_conn->prepare($fetchPrfacQuery);
    $fetchPrfacStmt->bind_param("i", $prfacId);
    $fetchPrfacStmt->execute();

    if ($fetchPrfacStmt->error) {
        die("ดึงข้อมูลไม่สำเร็จ: " . $fetchPrfacStmt->error);
    }

    $prfacData = $fetchPrfacStmt->get_result()->fetch_assoc();

    $newPo = generateNewPo();

    $insertAddpoQuery = "INSERT INTO addpo (pr, po, namecustomer, phone, namefac) VALUES (?, ?, ?, ?, ?)";
    $insertAddpoStmt = $db_conn->prepare($insertAddpoQuery);
    $insertAddpoStmt->bind_param("sssss", $prfacData['pr'], $newPo, $prfacData['namecustomer'], $prfacData['phone'], $prfacData['namefac']);
    $insertAddpoStmt->execute();

    if ($insertAddpoStmt->error) {
        die("เพิ่มข้อมูล addpo ไม่สำเร็จ: " . $insertAddpoStmt->error);
    }

    $lastInsertId = $insertAddpoStmt->insert_id;

    $fetchItemlistinsQuery = "SELECT * FROM itemlistfac WHERE pr_id = ? AND namefac = ?";
    $fetchItemlistinsStmt = $db_conn->prepare($fetchItemlistinsQuery);
    $fetchItemlistinsStmt->bind_param("ss", $prfacData['pr'], $prfacData['namefac']);
    $fetchItemlistinsStmt->execute();
    $itemlistinsData = $fetchItemlistinsStmt->get_result();

    while ($row = $itemlistinsData->fetch_assoc()) {
        $insertItemlistpoQuery = "INSERT INTO itemlistpo (pr_id, po_id, idpro_id, namepro, quantity, price, namefac) VALUES (?, ?, ?, ?, ?, ?, ?)";
        $insertItemlistpoStmt = $db_conn->prepare($insertItemlistpoQuery);
        $insertItemlistpoStmt->bind_param("ssssdds", $prfacData['pr'], $newPo, $row['idpro_id'], $row['namepro'], $row['quantity'], $row['price'], $row['namefac']);
        $insertItemlistpoStmt->execute();

        if ($insertItemlistpoStmt->error) {
            die("เพิ่มข้อมูล itemlistpo ไม่สำเร็จ: " . $insertItemlistpoStmt->error);
        }
    }

    $updateStatusStmt->bind_param("i", $prfacId);
    $updateStatusStmt->execute();

    if ($updateStatusStmt->error) {
        die("ปรับปรุงไม่สำเร็จ: " . $updateStatusStmt->error);
    }

    header("Location: ../prfac-main.php");
    exit();
}

function generateNewPo() {
    global $db_conn;

    $getLastPONumberQuery = "SELECT MAX(po) AS last_po FROM addpo";
    $getLastPONumberStmt = $db_conn->prepare($getLastPONumberQuery);
    $getLastPONumberStmt->execute();
    if ($getLastPONumberStmt->error) {
        die("ดึงข้อมูล PONumber ไม่สำเร็จ: " . $getLastPONumberStmt->error);
    }

    $lastPONumberResult = $getLastPONumberStmt->get_result();
    $lastPONumberRow = $lastPONumberResult->fetch_assoc();
    $lastPONumber = $lastPONumberRow['last_po'];

    $numericPart = (int)substr($lastPONumber, 3);
    $nextNumericPart = $numericPart + 1;

    $newPo = "PO-" . str_pad($nextNumericPart, 4, '0', STR_PAD_LEFT);

    while (isDuplicatePo($newPo)) {
        $nextNumericPart++;
        $newPo = "PO-" . str_pad($nextNumericPart, 4, '0', STR_PAD_LEFT);
    }

    return $newPo;
}

function isDuplicatePo($poNumber) {
    global $db_conn;

    $checkDuplicateQuery = "SELECT COUNT(*) AS count FROM addpo WHERE po = ?";
    $checkDuplicateStmt = $db_conn->prepare($checkDuplicateQuery);
    $checkDuplicateStmt->bind_param("s", $poNumber);
    $checkDuplicateStmt->execute();

    if ($checkDuplicateStmt->error) {
        die("เกิดข้อผิดพลาด: " . $checkDuplicateStmt->error);
    }

    $result = $checkDuplicateStmt->get_result();
    $row = $result->fetch_assoc();
    $count = $row['count'];

    return $count > 0;
}
?>
