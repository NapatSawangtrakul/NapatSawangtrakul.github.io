<?php
session_start();
require('../db_connect.php');

if (isset($_GET['id'])) {
    $id = mysqli_real_escape_string($db_conn, $_GET['id']);
    $query = "SELECT * FROM addpo WHERE id = '$id'";
    $result = mysqli_query($db_conn, $query);

    if (mysqli_num_rows($result) == 1) {
        $po = mysqli_fetch_assoc($result);
    } else {
        $_SESSION['message'] = "ไม่พบ PO";
        header("Location: ../po-main.php");
        exit();
    }
} else {
    $_SESSION['message'] = "ไม่พบ PO";
    header("Location: ../po-main.php");
    exit();
}
?>

<!doctype html>
<html lang="th">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/factory.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/html2canvas/1.4.1/html2canvas.min.js"></script>
    <title>รายละเอียดใบสั่งซื้อของโรงงาน</title>
</head>

<body>
    <div class="container-fluid mt-4 custom-container">
        <?php include('../message.php'); ?>

        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <h4>รายละเอียดใบสั่งซื้อของโรงงาน
                            <a href="../po-main.php" class="btn btn-danger float-end">กลับหน้าหลัก</a>
                            <?php
                            $poNumber = $po['pr'];
                            $itemListInsQuery = "SELECT * FROM itemlistfac WHERE pr_id = ?";
                            $itemListInsStmt = $db_conn->prepare($itemListInsQuery);
                            $itemListInsStmt->bind_param("s", $poNumber);
                            $itemListInsStmt->execute();
                            $itemListInsResult = $itemListInsStmt->get_result();?>
                            <button class="btn btn-primary float-end" onclick="generatePDF(<?= $po['id']; ?>)">พิมพ์ PDF</button>

                        </h4>
                    </div>
                    <div class="card-body print-container">
                        <?php
                        $query = mysqli_query($db_conn, "SELECT * FROM mf");
                        while ($row = mysqli_fetch_array($query)) {
                        ?>
                        <div class="form">
                            <table class="table">
                                <tr>
                                    <td>
                                        <h3><?php echo $row['nameTH']; ?></h3>
                                        <h3><?php echo $row['nameEN']; ?></h3>
                                        <h5><?php echo $row['locationTH']; ?></h5>
                                        <h5><?php echo $row['locationEN']; ?></h5>
                                        <h5>Tel : <?php echo $row['phone']; ?></h5>
                                    </td>
                                    <td>
                                        <h3>Purchase Order</h3>
                                        <h5 class="mt-4">เลขที่เอกสาร PR : <?= $po['pr']; ?></h5>
                                        <h5>เลขที่เอกสาร PO : <?= $po['po']; ?></h5>
                                        <h5>วันที่ : <?= date('d/m/Y', strtotime($po['date_created'])); ?></h5>
                                        <h5 for="namecustomer" class="form-label print-hidden">ชื่อลูกค้า :
                                            <?= $po['namecustomer']; ?></h5>
                                        <h5 for="namecustomer" class="form-label print-hidden">เบอร์โทรศัพท์ลูกค้า :
                                            <?= $po['phone']; ?></h5>
                                        <h5 for="namefac" class="form-label">ชื่อโรงงาน : <?php
                                                $namefacNumber = $po['namefac'];
                                                $factoryQuery = "SELECT Name, Location FROM factory WHERE id = ?";
                                                $factoryStmt = $db_conn->prepare($factoryQuery);
                                                $factoryStmt->bind_param("i", $namefacNumber);
                                                $factoryStmt->execute();
                                                $factoryResult = $factoryStmt->get_result();

                                                if ($factoryResult->num_rows === 1) {
                                                    $factoryData = $factoryResult->fetch_assoc();
                                                    echo $factoryData['Name'];
                                                    echo "<h5>" . $factoryData['Location'] . "</h5>";
                                                } else {
                                                    echo "ไม่พบโรงงาน";
                                                }
                                            ?></h5>
                                    </td>
                                </tr>
                            </table>
                        </div>
                        <?php
                        }
                        ?>

                        <table class="table table-bordered">
                            <thead>
                                <tr class="text-center align-middle">
                                    <th>รหัสสินค้า-ชื่อสินค้า</th>
                                    <th>จำนวนสินค้า(แผ่น)</th>
                                    <?php if ($po['status'] == 2 || $po['status'] == 3): ?>
                                    <th>วันที่รับสินค้า</th>
                                    <?php endif; ?>
                                    <?php if ($po['status'] != 0): ?>
                                    <th>สถานะของสินค้า</th>
                                    <?php endif; ?>
                                    <th>ราคาสินค้าต่อหน่วย(บาท)</th>
                                    <th>ราคารวม(บาท)</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $poNumber = $po['pr'];
                                $itemListInsQuery = "SELECT * FROM itemlistpo WHERE pr_id = ? AND namefac = ?";
                                $itemListInsStmt = $db_conn->prepare($itemListInsQuery);
                                $itemListInsStmt->bind_param("si", $poNumber, $namefacNumber);
                                $itemListInsStmt->execute();
                                $itemListInsResult = $itemListInsStmt->get_result();

                                $totalPrice = 0;
                                    $VAT = 0;
                                    if ($itemListInsResult->num_rows > 0) {
                                        while ($item = $itemListInsResult->fetch_assoc()) {
                                            $itemTotal = $item['quantity'] * $item['price'];
                                            $totalPrice += $itemTotal;
                                ?>
                                <tr>
                                    <td><?= htmlspecialchars($item['idpro_id']); ?> -
                                        <?= htmlspecialchars($item['namepro']); ?></td>
                                    <td class="text-center">
                                        <?= number_format(htmlspecialchars($item['quantity']), 0); ?></td>
                                    <?php if ($po['status'] == 2 || $po['status'] == 3): ?>
                                    <td class="text-center">
                                        <?php if (is_null($item['date_received'])): ?>
                                        ยังไม่รับ
                                        <?php else: ?>
                                        <?= date('d/m/Y', strtotime($item['date_received'])); ?>
                                        <?php endif; ?>
                                    </td>
                                    <?php endif; ?>


                                    <?php if ($po['status'] != 0): ?>
                                    <td class="text-center">
                                        <?php
    $dateCreated = new DateTime(datetime: $po['orderdate']);
    $dateReceived = new DateTime($item['date_received']);
    
    $interval = $dateCreated->diff($dateReceived);
    $daysLate = $interval->days;

    if ($item['status'] == 0) {
        echo 'ยังไม่รับ';
    } else {
        if ($daysLate > 15) {
            echo 'รับแล้วสินค้าล่าช้า ' . $daysLate . ' วัน'; 
        } else {
            echo 'รับแล้ว';
        }
    }
?>



                                        <?php endif; ?>
                                    <td class="text-end"><?= number_format(htmlspecialchars($item['price']), decimals: 2); ?></td>
                                    <td class="text-end"><?= number_format(htmlspecialchars($itemTotal), 2); ?></td>

                                </tr>
                                <?php
                                    }
                                    $VAT = $totalPrice * 0.07;
                                        $totalWithVAT = $totalPrice + $VAT;
                                         if ($po['status'] == 1 || $po['status'] == 2 || $po['status'] == 3){
                                            echo "<tr>
                                                <td colspan='3' style='border: 0;'></td>
                                                <td>รวมเป็นเงิน</td>
                                                <td class='text-end'>" . number_format($totalPrice, 2) . "</td>
                                            </tr>";
                                         } else {
                                        echo "<tr>
                                                <td colspan='2' style='border: 0;'></td>
                                                <td>รวมเป็นเงิน</td>
                                                <td class='text-end'>" . number_format($totalPrice, 2) . "</td>
                                            </tr>";
                                        }
                                } else {
                                    echo "<tr><td colspan='6'>ไม่พบรายการสินค้า</td></tr>";
                                }
                                ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>

<style>
.custom-container {
    margin-left: 100px;
    margin-right: 100px;
}

@media print {
    .print-hidden {
        display: none;
    }
}
</style>
<script>
async function generatePDF(id) {
    var { jsPDF } = window.jspdf;
    var content = document.querySelector('.print-container');

    // ซ่อนข้อมูลที่ไม่ต้องการ
    var customerElements = document.querySelectorAll('h5[for="namecustomer"], h5[for="namecustomer"] + h5');
    if (customerElements.length > 0) {
        customerElements.forEach(el => el.classList.add('hide-during-print'));
    }

    document.querySelector('button[onclick^="generatePDF"]').innerText = "กำลังสร้าง PDF...";

    await html2canvas(content, { scale: 2 }).then((canvas) => {
        var imgData = canvas.toDataURL('image/png');
        var pdf = new jsPDF('p', 'pt', 'a4');
        var imgWidth = 595.28;
        var imgHeight = canvas.height * imgWidth / canvas.width;
        var pageHeight = 841.89;
        var heightLeft = imgHeight;
        var position = 0;

        pdf.addImage(imgData, 'PNG', 0, position, imgWidth, imgHeight);
        heightLeft -= pageHeight;

        while (heightLeft > 0) {
            position = heightLeft - imgHeight;
            pdf.addPage();
            pdf.addImage(imgData, 'PNG', 0, position, imgWidth, imgHeight);
            heightLeft -= pageHeight;
        }

        var filename = 'ใบสั่งซื้อของโรงงาน_' + encodeURIComponent('<?= isset($po['po']) ? $po['po'] : "ไม่ระบุ"; ?>') + '.pdf';
        pdf.save(filename);
    });

    // คืนค่าข้อมูลที่ซ่อน
    if (customerElements.length > 0) {
        customerElements.forEach(el => el.classList.remove('hide-during-print'));
    }

    // คืนค่า UI
    document.querySelector('button[onclick^="generatePDF"]').innerText = "พิมพ์ PDF";

    // ส่งคำขอ XHR หรือใช้ fetch
    fetch(`po-print.php?id=${id}`)
        .then(response => {
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            window.location.href = '../po-view.php';
        })
        .catch(error => {
            console.error('There was a problem with the fetch operation:', error);
        });
}
</script>