<?php
session_start();
require('../db_connect.php');

if (isset($_GET['pr_value'])) {
    $prValue = mysqli_real_escape_string($db_conn, $_GET['pr_value']);

    $query = "SELECT * FROM itemlistins WHERE pr_id = '$prValue'";
    $result = mysqli_query($db_conn, $query);

    if ($result) {
        $data = array();
        
        $addprQuery = "SELECT date_created, namecustomer FROM addpr WHERE pr = '$prValue'";
        $addprResult = mysqli_query($db_conn, $addprQuery);
        $addprData = mysqli_fetch_assoc($addprResult);

        $data['date_created'] = $addprData['date_created'];
        $data['namecustomer'] = $addprData['namecustomer'];

        $data['items'] = array();
        while ($row = mysqli_fetch_assoc($result)) {
            $data['items'][] = $row;
        }
        echo json_encode($data);
    } else {
        echo json_encode(['error' => 'ดึงข้อมูลไม่สำเร็จ']);
    }
} else {
    echo json_encode(['error' => 'ไม่พบ PR']);
}
?>