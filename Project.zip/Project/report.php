<?php
require 'db_connect.php'; 
include_once("maindrop.php");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="factory.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <title>รายงาน</title>
</head>
<body>
<div class="container-fluid mt-4 custom-container">
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <h4>รายงานสรุปการสั่งซื้อ</h4>
                </div>
                <div class="card-body text-center">
                    <form action="Report/report-po.php" method="GET">
                        <label for="start_date">วันที่เริ่มต้นรายงาน:</label>
                            <input type="date" name="start_date" required>
                        <label for="end_date">วันที่สิ้นสุดรายงาน:</label>
                            <input type="date" name="end_date" required>
                        <button type="submit" class="btn btn-outline-dark">ทำรายการสรุป</button>
                    </form>
                </div>
            </div>

            <div class="card">
                <div class="card-header">
                    <h4>รายงานใบต้นทุนที่ยังไม่ได้รับจากโรงงาน</h4>
                </div>
                <div class="card-body text-center">
                    <form action="Report/report-notaccept.php" method="GET">
                        <button type="submit" class="btn btn-outline-dark">ทำรายงาน</button>
                    </form>
                </div>
            </div>

            <div class="card">
                <div class="card-header">
                    <h4>รายงานใบต้นทุนที่ยังไม่ได้สั่งซื้อ</h4>
                </div>
                <div class="card-body text-center">
                    <form action="Report/report-notbuy.php" method="GET">
                        <label for="start_date">วันที่เริ่มต้นรายงาน:</label>
                            <input type="date" name="start_date" required>
                        <label for="end_date">วันที่สิ้นสุดรายงาน:</label>
                            <input type="date" name="end_date" required>
                        <button type="submit" class="btn btn-outline-dark">ทำรายงาน</button>
                    </form>
                </div>
            </div>

            <div class="card">
                <div class="card-header">
                    <h4>รายงานสินค้าค้างรับ</h4>
                </div>
                <div class="card-body text-center">
                    <form action="Report/report-delayed.php" method="GET">
                        <button type="submit" class="btn btn-outline-dark">ทำรายงาน</button>
                    </form>
                </div>
            </div>

            <div class="card">
                <div class="card-header">
                    <h4>รายงานสรุปโรงงานที่ล่าช้า</h4>
                </div>
                <div class="card-body text-center">
                    <form action="Report/report-facdelayed.php" method="GET">
                        <label for="start_date">วันที่เริ่มต้นรายงาน:</label>
                            <input type="date" name="start_date" required>
                        <label for="end_date">วันที่สิ้นสุดรายงาน:</label>
                            <input type="date" name="end_date" required>
                        <button type="submit" class="btn btn-outline-dark">ทำรายงานสรุป</button>
                    </form>
                </div>
            </div>


        </div>
    </div>
</div>
<style>
.custom-container {
            margin-left: 200px;
            margin-right: 50px;
        }
</style>                       
</body>
</html>
