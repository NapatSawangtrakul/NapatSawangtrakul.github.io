<?php
require 'db_connect.php';
include_once("maindrop.php");
function formatPhoneNumber($phoneNumber) {
    $phoneNumber = preg_replace('/[^\d]/', '', $phoneNumber);
    if (strlen($phoneNumber) == 10) {
        return preg_replace('/(\d{3})(\d{3})(\d{4})/', '$1-$2-$3', $phoneNumber);
    } else {
        return $phoneNumber;
    }
}

$recordsPerPage = 10;

if (isset($_GET['page'])) {
    $currentPage = $_GET['page'];
} else {
     $currentPage = 1;
}

$offset = ($currentPage - 1) * $recordsPerPage;

$query = "SELECT * FROM addpr LIMIT $offset, $recordsPerPage";
$query_run = mysqli_query($db_conn, $query);

$totalPages = ceil(mysqli_num_rows(mysqli_query($db_conn, "SELECT COUNT(*) FROM addpr")) / $recordsPerPage);

function updateStatusIfExpired($db_conn) {
    $currentDate = date("Y-m-d");
    $query = "SELECT id, orderdate, status FROM addprfac WHERE status = 2";
    $result = mysqli_query($db_conn, $query);

    if (mysqli_num_rows($result) > 0) {
        while ($row = mysqli_fetch_assoc($result)) {
            $orderdate = $row['orderdate'];
            $id = $row['id'];
            $status = $row['status'];

            $daysDifference = (strtotime($currentDate) - strtotime($orderdate)) / (60 * 60 * 24);

            if ($daysDifference > 30 && $status == 2) {
                $updateQuery = "UPDATE addprfac SET status = 5 WHERE id = ?";
                $stmt = $db_conn->prepare($updateQuery);
                $stmt->bind_param("i", $id);
                $stmt->execute();
            }
        }
    }
}

updateStatusIfExpired($db_conn);
?>

<!doctype html>
<html lang="th">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/factory.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <title>รายการใบต้นทุน</title>
</head>

<body>
    <div class="container-fluid mt-4 custom-container">
        <?php include('message.php'); ?>
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <h4>รายการใบต้นทุน
                            <?php if ($_SESSION['user_type'] != 'S') : ?>
                                <a href="PRFac/prfac-ins.php" class="btn btn-primary float-end">เพิ่มราคาใบต้นทุน</a>
                            <?php endif; ?>
                            <?php if ($_SESSION['user_type'] == 'S') : ?>
                                <a href="PRFac/prfac-ins.php" class="btn btn-primary float-end hidden-btn">เพิ่มราคาใบต้นทุน</a>
                            <?php endif; ?>
                        </h4>
                    </div>
                    <div class="card-body">
                        <div class="d-flex justify-content-between mb-3 align-middle">
                            <div class="form-group">
                                <label for="date_from">วันที่เริ่มต้นค้นหา</label>
                                <input type="date" class="form-control border border-secondary" id="date_from">
                            </div>
                            <div class="form-group">
                                <label for="date_to">วันที่สิ้นสุดค้นหา</label>
                                <input type="date" class="form-control border border-secondary" id="date_to">
                            </div>

                            <div class="form-group">
                                <label for="namecustomer">ชื่อลูกค้าหรือเลขที่เอกสาร PR</label>
                                <input type="text" class="form-control border border-secondary" id="namecustomer">
                            </div>
                            <div class="form-group">
                                <label for="status">สถานะ</label>
                                <select class="form-control border border-secondary" id="status" name="status">
                                    <option value="">ทั้งหมด</option>
                                    <option value="0">ยังไม่ดำเนินการ</option>
                                    <option value="1">รอตอบกลับ</option>
                                    <option value="2">ตอบกลับ</option>
                                    <option value="3">ยกเลิกดำเนินการ</option>
                                    <option value="4">สั่งซื้อ</option>
                                    <option value="5">หมดอายุ</option>
                                    
                                </select>
                            </div>
                            <button type="button" class="btn btn-primary" id="searchButton">ค้นหา</button>
                            <button type="button" class="btn btn-secondary" id="resetButton">รีเซ็ต</button>
                        </div>


                        <div class="card-body">
                            <table class="table table-bordered table-striped align-middle">
                                <thead>
                                    <tr class="text-center align-middle">
                                        <th>ลำดับที่</th>
                                        <th>วันที่</th>
                                        <th>เลขที่เอกสาร PR</th>
                                        <th>ชื่อลูกค้า</th>
                                        <th>เบอร์โทรศัพท์ลูกค้า</th>
                                        <th>ชื่อโรงงาน</th>
                                        <th>สถานะ</th>
                                        <th></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php 
                                    $results_per_page = 10;
                                    $query = "SELECT * FROM addprfac ORDER BY pr DESC";
                                    $query_run = mysqli_query($db_conn, $query);

                                    if (mysqli_num_rows($query_run) > 0) {
                                        $total_results = mysqli_num_rows($query_run);
                                        $total_pages = ceil($total_results / $results_per_page);

                                        if (!isset($_GET['page'])) {
                                            $page = 1;
                                        } else {
                                            $page = $_GET['page'];
                                        }
                                        
                                        $this_page_first_result = ($page - 1) * $results_per_page;

                                        $query = "SELECT * FROM addprfac ORDER BY pr DESC LIMIT $this_page_first_result, $results_per_page";
                                        $query_run = mysqli_query($db_conn, $query);

                                        $i = ($currentPage - 1) * $recordsPerPage + 1;
                                        foreach ($query_run as $prfac) {
                                            if ($prfac['status'] !== 3) {
                                                ?>
                                    <tr class="align-middle">
                                        <td><?= $i; ?></td>
                                        <td><?= date("d/m/Y", strtotime($prfac['date_created'])); ?></td>
                                        <td><?= $prfac['pr']; ?></td>
                                        <td><?= $prfac['namecustomer']; ?></td>
                                        <td><?= formatPhoneNumber($prfac['phone']); ?></td>
                                        <td>
                                            <?php
                                                        $namefacNumber = $prfac['namefac'];
                                                        $factoryQuery = "SELECT Name FROM factory WHERE id = ?";
                                                        $factoryStmt = $db_conn->prepare($factoryQuery);
                                                        $factoryStmt->bind_param("i", $namefacNumber);
                                                        $factoryStmt->execute();
                                                        $factoryResult = $factoryStmt->get_result();
                                                        if ($factoryResult->num_rows === 1) {
                                                            $factoryData = $factoryResult->fetch_assoc();
                                                            echo $factoryData['Name'];
                                                        } else {
                                                            echo "ไม่พบโรงงาน";
                                                        }
                                                        ?>
                                        </td>
                                        <td>
                                            <?php if ($prfac['status'] == 0): ?>
                                            <span style="color:#080808;">ยังไม่ดำเนินการ</span>
                                            <?php elseif ($prfac['status'] == 1): ?>
                                            <span style="color:#080808;">รอตอบกลับ</span>
                                            <?php elseif ($prfac['status'] == 2): ?>
                                            <span style="color:#080808;">ตอบกลับ</span>
                                            <?php elseif ($prfac['status'] == 3): ?>
                                            <span style="color:#080808;">ยกเลิกดำเนินการ</span>
                                            <?php elseif ($prfac['status'] == 4): ?>
                                            <span style="color:#080808;">สั่งซื้อ</span>
                                            <?php elseif ($prfac['status'] == 5): ?>
                                            <span style="color:#080808;">หมดอายุ</span>
                                            <?php endif; ?>
                                        </td>
                                        <td class="text-center align-middle">
                                            <div class="d-flex align-items-center">
                                                <a href="PRFac/prfac-view.php?id=<?= $prfac['id']; ?>"
                                                    class="btn btn-info btn-sm">View</a>

                                                <?php if ($prfac['status'] == 2 && $_SESSION['user_type'] != 'S'): ?>
                                                <form action="PO/order-process.php" method="POST" class="d-inline">
                                                    <button type="submit" name="Order_po" value="<?= $prfac['id']; ?>"
                                                        class="btn btn-warning btn-sm" style="font-size: 12px">Create PO</button>
                                                </form>
                                                <?php elseif ($prfac['status'] != 2 && $_SESSION['user_type'] == 'S'): ?>
                                                <form action="PO/order-process.php" method="POST" class="d-inline">
                                                    <button type="submit" name="Order_po" value="<?= $prfac['id']; ?>"
                                                        class="btn btn-warning btn-sm hidden-btn" style="font-size: 12px">Create PO</button>
                                                </form>
                                                <?php endif; ?>

                                                <?php if ($prfac['status'] == 0 || $prfac['status'] == 1): ?>
                                                    <form action="PRFac/prfac-submit.php" method="POST" class="d-inline">
                                                    <button type="submit" name="delete_prfac"
                                                        value="<?= $prfac['id']; ?>"
                                                        class="btn btn-danger btn-sm">Delete</button>
                                                </form>
                                                <?php elseif ($prfac['status'] != 0 || $prfac['status'] != 1 && $_SESSION['user_type'] == 'S'): ?>
                                                    <form action="PRFac/prfac-submit.php" method="POST" class="d-inline">
                                                    <button type="submit" name="delete_prfac"
                                                        value="<?= $prfac['id']; ?>"
                                                        class="btn btn-danger btn-sm hidden-btn">Delete</button>
                                                </form>
                                                <?php endif; ?>
                                            </div>
                                        </td>
                                    </tr>
                                    <?php
                                            }
                                            $i++;
                                        }

                                        echo '<div class="pagination">';
                                        for ($page = 1; $page <= $total_pages; $page++) {
                                            echo '<a href="prfac-main.php?page=' . $page . '">' . $page . '</a>';
                                            if ($page != $total_pages) {
                                                echo ' &nbsp; ';
                                            }
                                        }
                                        
                                        echo '</div>';
                                    } else {
                                        echo "<center>";
                                        echo "<h5>ไม่พบรายการ</h5>";
                                        echo "</center>";
                                    }
                                    ?>

                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
        <script>
        document.addEventListener("DOMContentLoaded", function() {
            const dateFromInput = document.getElementById("date_from");
            const dateToInput = document.getElementById("date_to");
            const customerInput = document.getElementById("namecustomer");
            const statusInput = document.getElementById("status");
            const searchButton = document.getElementById("searchButton");
            const resetButton = document.getElementById("resetButton");
            const tableBody = document.querySelector("tbody");

            function performSearch() {
                const dateFrom = dateFromInput.value;
                const dateTo = dateToInput.value;
                const customer = customerInput.value;
                const status = statusInput.value;
                fetch(
                        `PRFac/prfac-search.php?date_from=${dateFrom}&date_to=${dateTo}&namecustomer=${customer}&status=${status}`)
                    .then(response => response.text())
                    .then(data => {
                        tableBody.innerHTML = data;
                    })
                    .catch(error => {
                        console.error('Error:', error);
                    });
            }

            resetButton.addEventListener("click", function() {
            window.location.href = "prfac-main.php";
        });

            searchButton.addEventListener("click", performSearch);
            resetButton.addEventListener("click", resetSearch);
        });
        </script>
<style>
    .custom-container {
            margin-left: 200px;
            width: calc(100% - 200px);
        }
    .hidden-btn {
        display: none;
    }

    div.relative {
        position: relative;
        left: 200px;
    }
</style>
</body>
</html>

