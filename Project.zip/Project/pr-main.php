<?php
require('db_connect.php');
include_once("maindrop.php");
function formatPhoneNumber($phoneNumber) {
    $phoneNumber = preg_replace('/[^\d]/', '', $phoneNumber);
    if (strlen($phoneNumber) == 10) {
        return preg_replace('/(\d{3})(\d{3})(\d{4})/', '$1-$2-$3', $phoneNumber);
    } else {
        return $phoneNumber;
    }
}
?>

<!doctype html>
<html lang="th">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="css/factory.css">
    <title>ใบสั่งซื้อของลูกค้า</title>
</head>

<body>
    <div class="container-fluid mt-4 custom-container">
        <?php include('message.php'); ?>
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <h4>รายการใบสั่งซื้อของลูกค้า
                            <?php if ($_SESSION['user_type'] != 'S') : ?>
                                <a href="PR/pr-create.php" class="btn btn-primary float-end hidden-btn">เพิ่มใบสั่งซื้อของลูกค้า</a>
                            <?php endif; ?>
                            <?php if ($_SESSION['user_type'] == 'S') : ?>
                                <a href="PR/pr-create.php" class="btn btn-primary float-end">เพิ่มใบสั่งซื้อของลูกค้า</a>
                            <?php endif; ?>
                        </h4>
                    </div>
                    <div class="card-body">
                    <div class="d-flex justify-content-between mb-3 align-middle">
                        <div class="form-group">
                            <label for="date_from">วันที่เริ่มต้นค้นหา</label>
                            <input type="date" class="form-control border border-secondary" id="date_from">
                        </div>
                        <div class="form-group">
                            <label for="date_to">วันที่สิ้นสุดค้นหา</label>
                            <input type="date" class="form-control border border-secondary" id="date_to">
                        </div>
                        <div class="form-group">
                            <label for="namecustomer">ชื่อลูกค้าหรือเลขที่เอกสาร PR</label>
                            <input type="text" class="form-control border border-secondary" id="namecustomer">
                        </div>
                        <div class="form-group">
                            <label for="status">สถานะ</label>
                            <select class="form-control border border-secondary" id="status" name="status">
                                <option value="">ทั้งหมด</option>
                                <option value="0">ยังไม่ได้ดำเนินการ</option>
                                <option value="1">ดำเนินการเรียบร้อย</option>
                                <option value="2">ยกเลิกดำเนินการ</option>
                                <option value="3">ข้อมูลยังไม่ครบ</option>
                                <option value="4">ข้อมูลครบ</option>
                            </select>
                        </div>
                        <button type="button" class="btn btn-primary" id="searchButton">ค้นหา</button>
                        <button type="button" class="btn btn-secondary" id="resetButton">รีเซ็ต</button>
                    </div>

                    <div class="card-body">
                        <table class="table table-bordered table-striped align-middle" name="show" id="show">
                            <thead>
                                <tr class="text-center align-middle">
                                    <th>ลำดับที่</th>
                                    <th>วันที่</th>
                                    <th>เลขที่เอกสาร PR</th>
                                    <th>ชื่อลูกค้า</th>
                                    <th>เบอร์โทรศัพท์ลูกค้า</th>
                                    <th>สถานะ</th>
                                    <th></th>
                                </tr>
                            </thead>
                            <tbody>
                            <?php
                                $results_per_page = 10;
                                $query = "SELECT * FROM addpr ORDER BY pr DESC";
                                $query_run = mysqli_query($db_conn, $query);

                                if (mysqli_num_rows($query_run) > 0) {
                                    $total_results = mysqli_num_rows($query_run);
                                    $total_pages = ceil($total_results / $results_per_page);

                                    if (!isset($_GET['page'])) {
                                        $page = 1;
                                    } else {
                                        $page = $_GET['page'];
                                    }
                                    $this_page_first_result = ($page - 1) * $results_per_page;
                                    
                                    $query = "SELECT * FROM addpr ORDER BY pr DESC LIMIT $this_page_first_result, $results_per_page";
                                    $query_run = mysqli_query($db_conn, $query);

                                    $i = $this_page_first_result + 1;
                                    foreach ($query_run as $pr) {
                                        ?>
                                        <tr class="align-middle">
                                            <td><?= $i; ?></td>
                                            <td><?= date("d/m/Y", strtotime($pr['date_created'])); ?></td>
                                            <td><?= $pr['pr']; ?></td>
                                            <td><?= $pr['namecustomer']; ?></td>
                                            <td><?= formatPhoneNumber($pr['phone']); ?></td>
                                            <td>
                                                <?php if ($pr['status'] == 0): ?>
                                                    <span style="color:#080808;">ยังไม่ได้ดำเนินการ</span>
                                                <?php elseif ($pr['status'] == 1): ?>
                                                    <span style="color:#080808;">ดำเนินการเรียบร้อย</span>
                                                <?php elseif ($pr['status'] == 2): ?>
                                                    <span style="color:#080808;">ยกเลิกดำเนินการ</span>
                                                <?php elseif ($pr['status'] == 3): ?>
                                                    <span style="color:#080808;">ข้อมูลยังไม่ครบ</span>
                                                <?php elseif ($pr['status'] == 4): ?>
                                                    <span style="color:#080808;">ข้อมูลครบ</span>
                                                <?php endif; ?>
                                            </td>
                                            <td class="text-center align-middle">
                                                <div class="d-flex align-items-center">
                                                    <a href="PR/pr-view.php?id=<?= $pr['id']; ?>" class="btn btn-info btn-sm">View</a>

                                                    <?php if ($pr['status'] == 0 && $_SESSION['user_type'] == 'S'): ?>
                                                        <a href="PR/pr-edit.php?id=<?= $pr['id']; ?>" class="btn btn-success btn-sm">edit</a>
                                                    <?php elseif ($pr['status'] != 0 && $_SESSION['user_type'] != 'S'): ?>
                                                        <a href="PR/pr-edit.php?id=<?= $pr['id']; ?>" class="btn btn-success btn-sm hidden-btn">edit</a>
                                                    <?php endif; ?>

                                                    <?php if ($pr['status'] == 0 && $_SESSION['user_type'] != 'S'): ?>
                                                        <a href="PR/pr-choosefactory.php?id=<?= $pr['id']; ?>" class="btn btn-success btn-sm">Factory select</a>
                                                    <?php elseif ($pr['status'] != 0 && $_SESSION['user_type'] != 'S'): ?>
                                                        <a href="PR/pr-choosefactory.php?id=<?= $pr['id']; ?>" class="btn btn-success btn-sm hidden-btn">Factory select</a>
                                                    <?php endif; ?>      
                                                    
                                                    <?php if ($pr['status'] == 4 && $_SESSION['user_type'] == 'S'): ?>
                                                        <a href="PR/export_csv.php?id=<?= $pr['id']; ?>" class="btn btn-success btn-sm float-end">Export CSV</a>
                                                    <?php elseif ($pr['status'] != 4 && $_SESSION['user_type'] != 'S'): ?>
                                                        <a href="PR/export_csv.php?id=<?= $pr['id']; ?>" class="btn btn-success btn-sm float-end hidden-btn">Export CSV</a>
                                                    <?php endif; ?>    

                                                    <?php if ($pr['status'] == 0): ?>
                                                        <form action="PR/pr-submit.php" method="POST" class="d-inline">
                                                            <button type="submit" name="delete_pr" value="<?= $pr['id']; ?>" class="btn btn-danger btn-sm">Delete</button>
                                                        </form>
                                                    <?php elseif ($pr['status'] != 0): ?>
                                                        <form action="PR/pr-submit.php" method="POST" class="d-inline">
                                                            <button type="submit" name="delete_pr" value="<?= $pr['id']; ?>" class="btn btn-danger btn-sm hidden-btn">Delete</button>
                                                        </form>
                                                    <?php endif; ?>
                                                </div>
                                            </td>
                                        </tr>
                                    <?php
                                        $i++;
                                    }

                                    echo '<div class="pagination">';
                                    for ($page = 1; $page <= $total_pages; $page++) {
                                        echo '<a href="pr-main.php?page=' . $page . '">' . $page . '</a>';
                                        if ($page != $total_pages) {
                                            echo ' &nbsp; ';
                                        }
                                    }
                                    echo '</div>';
                                } else {
                                    echo "<center>";
                                    echo "<h5>ไม่พบรายการ</h5>";
                                    echo "</center>";
                                }
                                ?>

                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
<script>
        document.addEventListener("DOMContentLoaded", function () {
            const dateFromInput = document.getElementById("date_from");
            const dateToInput = document.getElementById("date_to");
            const customerInput = document.getElementById("namecustomer");
            const statusInput = document.getElementById("status");
            const searchButton = document.getElementById("searchButton");
            const resetButton = document.getElementById("resetButton");
            const tableBody = document.querySelector("tbody");

            function performSearch() {
                const dateFrom = dateFromInput.value;
                const dateTo = dateToInput.value;
                const customer = customerInput.value;
                const status = statusInput.value;
                fetch(`PR/pr-search.php?date_from=${dateFrom}&date_to=${dateTo}&namecustomer=${customer}&status=${status}`)
                    .then(response => response.text())
                    .then(data => {
                        tableBody.innerHTML = data;
                    })
                    .catch(error => {
                        console.error('Error:', error);
                    });
            }

            resetButton.addEventListener("click", function() {
            window.location.href = "pr-main.php";
        });

            searchButton.addEventListener("click", performSearch);
            resetButton.addEventListener("click", resetSearch);
        });
</script>
<style>
    .custom-container {
            margin-left: 200px;
            width: calc(100% - 200px);
        }
    .hidden-btn {
        display: none;
    }

    div.relative {
        position: relative;
        left: 200px;
    }
</style>
</body>
</html>
