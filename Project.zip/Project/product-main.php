<?php
    require 'db_connect.php';
    include_once("maindrop.php");
?>
<!doctype html>
<html lang="th">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="factory.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <title>สินค้า</title>
</head>
<body>
    <div class="container-fluid mt-4 custom-container">
        <?php include('message.php'); ?>
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <h4>รายละเอียดสินค้า
                            <a href="Product/product-create.php" class="btn btn-primary float-end">เพิ่มสินค้า</a>
                        </h4>
                    </div>
                    <div class="card-body">
                    <div class="d-flex justify-content-between mb-3">
                        <div class="form-group">
                            <label for="idpro">รหัสสินค้าหรือชื่อสินค้า</label>
                            <input type="text" class="form-control border border-secondary" id="idpro">
                        </div>
                        <div class="form-group">
                            <label for="status">สถานะ</label>
                            <select class="form-control border border-secondary" id="status" name="status">
                                <option value="">ทั้งหมด</option>
                                <option value="0">ไม่ใช้งาน</option>
                                <option value="1">ใช้งาน</option>
                            </select>
                        </div>
                        <button type="button" class="btn btn-primary" id="searchButton">ค้นหา</button>
                        <button type="button" class="btn btn-secondary" id="resetButton">รีเซ็ต</button>
                    </div>
                        <table class="table table-bordered table-striped" name="show" id="show">
                            <thead>
                                <tr class="text-center align-middle">
                                    <th class="textcss">รหัสสินค้า</th>
                                    <th class="textcss">ชื่อสินค้า</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                    $results_per_page = 10; 
                                    $query = "SELECT * FROM product";
                                    $query_run = mysqli_query($db_conn, $query);

                                    if(mysqli_num_rows($query_run) > 0) {
                                        $total_results = mysqli_num_rows($query_run);
                                        $total_pages = ceil($total_results / $results_per_page);

                                        if (!isset($_GET['page'])) {
                                            $page = 1;
                                        } else {
                                            $page = $_GET['page'];
                                        }
                                        $this_page_first_result = ($page - 1) * $results_per_page;
                                    
                                        $query = "
                                                    SELECT * FROM product 
                                                    ORDER BY 
                                                        SUBSTRING_INDEX(idpro, '-', 1) ASC, -- Sort by the prefix before the first hyphen
                                                        CAST(SUBSTRING_INDEX(SUBSTRING_INDEX(idpro, '-', -2), '-', 1) AS UNSIGNED) ASC, -- Sort by the first numeric component
                                                        CAST(SUBSTRING_INDEX(idpro, '-', -1) AS DECIMAL(10, 2)) ASC, -- Sort by the last numeric component
                                                        idpro ASC -- Fallback to full idpro for final sort
                                                    LIMIT $this_page_first_result, $results_per_page
                                                ";
                                                $query_run = mysqli_query($db_conn, $query);




                                        $i = $this_page_first_result + 1;
                                        foreach($query_run as $product) {
                                ?>
                                <tr class="align-middle">
                                    <td><?= $product['idpro']; ?></td>
                                    <td><?= $product['namepro']; ?></td>
                                    <td class="text-center align-middle">
                                        <div class="d-flex align-items-center">
                                            <a href="Product/product-edit.php?idpro=<?= $product['idpro']; ?>"
                                                class="btn btn-success btn-sm">Edit</a>

                                            <?php if ($product['status'] == 0): ?>
                                            <form action="Product/product-submit.php" method="POST" class="d-inline">
                                                <button type="submit" name="active_product"
                                                    value="<?=$product['idpro'];?>"
                                                    class="btn btn-primary btn-sm">active</button>
                                            </form>
                                            <?php elseif ($product['status'] == 1): ?>
                                            <form action="Product/product-submit.php" method="POST" class="d-inline">
                                                <button type="submit" name="active_product"
                                                    value="<?=$product['idpro'];?>"
                                                    class="btn btn-primary btn-sm hidden-btn">active</button>
                                            </form>
                                            <?php endif; ?>

                                            <?php if ($product['status'] == 0): ?>
                                            <form action="Product/product-submit.php" method="POST" class="d-inline">
                                                <button type="submit" name="delete_product"
                                                    value="<?=$product['idpro'];?>"
                                                    class="btn btn-danger btn-sm hidden-btn">Delete</button>
                                            </form>
                                            <?php elseif ($product['status'] == 1): ?>
                                            <form action="Product/product-submit.php" method="POST" class="d-inline">
                                                <button type="submit" name="delete_product"
                                                    value="<?=$product['idpro'];?>"
                                                    class="btn btn-danger btn-sm">Delete</button>
                                            </form>
                                            <?php endif; ?>
                                        </div>
                                    </td>
                                </tr>
                                <?php
                                        }
                                        echo '<div class="pagination">';
                                    for ($page = 1; $page <= $total_pages; $page++) {
                                        echo '<a href="product-main.php?page=' . $page . '">' . $page . '</a>';
                                        if ($page != $total_pages) {
                                            echo ' &nbsp; ';
                                        }
                                    }
                                    echo '</div>';
                                    } else {
                                        echo "<center>";
                                        echo "<h5>ไม่พบรายการ</h5>";
                                        echo "</center>";
                                    }
                                ?>

                            </tbody>
                        </table>

                    </div>
                </div>
            </div>
        </div>
    </div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
<script>
        document.addEventListener("DOMContentLoaded", function () {
            const productInput = document.getElementById("idpro");
            const statusInput = document.getElementById("status");
            const searchButton = document.getElementById("searchButton");
            const resetButton = document.getElementById("resetButton");
            const tableBody = document.querySelector("tbody");

            function performSearch() {
                const product = productInput.value;
                const status = statusInput.value;
                fetch(`Product/product-search.php?idpro=${product}&status=${status}`)
                    .then(response => response.text())
                    .then(data => {
                        tableBody.innerHTML = data;
                    })
                    .catch(error => {
                        console.error('เกิดข้อผิดพลาด', error);
                    });
            }

            resetButton.addEventListener("click", function() {
            window.location.href = "product-main.php";
        });

            searchButton.addEventListener("click", performSearch);
            resetButton.addEventListener("click", resetSearch);
        });
</script>
<style>
    .custom-container {
        margin-left: 200px;
        margin-right: 50px;
    }
    .hidden-btn {
        display: none;
    }
</style>
</body>
</html>