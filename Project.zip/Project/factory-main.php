<?php
    require 'db_connect.php';
    include_once("maindrop.php");
?>
<!doctype html>
<html lang="th">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="factory.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <title>โรงงาน</title>
</head>
<body>
    <div class="container-fluid mt-4 custom-container">
        <?php include('message.php'); ?>
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <h4>รายละเอียดโรงงาน
                            <a href="Fac/factory-create.php" class="btn btn-primary float-end">เพิ่มโรงงาน</a>
                        </h4>
                    </div>
                    <div class="card-body">

                        <table class="table table-bordered table-striped align-middle">
                            <thead>
                                <tr class="text-center align-middle">
                                    <th>ลำดับที่</th>
                                    <th>ชื่อโรงงาน</th>
                                    <th>ที่อยู่โรงงาน</th>
                                    <th>ผู้ที่ติดต่อ</th>
                                    <th>เบอร์ติดต่อ</th>
                                    <th>Linetoken</th>
                                    <th>คำอธิบายประกอบ</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php 
                                    $query = "SELECT * FROM factory";
                                    $query_run = mysqli_query($db_conn, $query);

                                    $i = 1;
                                    if(mysqli_num_rows($query_run) > 0)
                                    {
                                        foreach($query_run as $factory)
                                        {
                                            ?>
                                <tr class="align-middle">
                                    <td><?= $i; ?></td>
                                    <td><?= $factory['Name']; ?></td>
                                    <td><?= $factory['Location']; ?></td>
                                    <td><?= $factory['Contact']; ?></td>
                                    <td><?= $factory['Phone']; ?></td>
                                    <td><?= $factory['Linetoken']; ?></td>
                                    <td><?= $factory['Annotaion']; ?></td>
                                    <td class="text-center align-middle">
                                        <div class="d-flex align-items-center">
                                            <a href="Fac/factory-edit.php?id=<?= $factory['id']; ?>"
                                                class="btn btn-success btn-sm">Edit</a>

                                            <?php if ($factory['Status'] == 0): ?>
                                            <form action="Fac/factory-submit.php" method="POST" class="d-inline">
                                                <button type="submit" name="active_factory"
                                                    value="<?=$factory['id'];?>"
                                                    class="btn btn-primary btn-sm">active</button>
                                            </form>
                                            <?php elseif ($factory['Status'] == 1): ?>
                                            <form action="Fac/factory-submit.php" method="POST" class="d-inline">
                                                <button type="submit" name="active_factory"
                                                    value="<?=$factory['id'];?>"
                                                    class="btn btn-primary btn-sm hidden-btn">active</button>
                                            </form>
                                            <?php endif; ?>

                                            <?php if ($factory['Status'] == 0): ?>
                                            <form action="Fac/factory-submit.php" method="POST" class="d-inline">
                                                <button type="submit" name="delete_factory"
                                                    value="<?=$factory['id'];?>"
                                                    class="btn btn-danger btn-sm hidden-btn">Delete</button>
                                            </form>
                                            <?php elseif ($factory['Status'] == 1): ?>
                                            <form action="Fac/factory-submit.php" method="POST" class="d-inline">
                                                <button type="submit" name="delete_factory"
                                                    value="<?=$factory['id'];?>"
                                                    class="btn btn-danger btn-sm">Delete</button>
                                            </form>
                                            <?php endif; ?>
                                        </div>
                                    </td>
                                </tr>
                                <?php
                                            $i++;
                                        }
                                        
                                    }
                                    else
                                    {
                                        echo "<center>";
                                        echo "<h5>ไม่พบรายการ</h5>";
                                        echo "</center>";
                                    }
                                ?>
                            </tbody>
                        </table>

                    </div>
                </div>
            </div>
        </div>
    </div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
<style>
    .custom-container {
        margin-left: 200px;
        margin-right: 50px;
    }
    .hidden-btn {
        display: none;
    }
</style>
</body>
</html>