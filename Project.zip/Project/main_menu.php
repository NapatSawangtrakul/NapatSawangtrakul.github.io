<?php 
include_once("maindrop.php");
require_once("db_connect.php");
?>
<!doctype html>
<html lang="en">
  <head>

    <link rel="stylesheet" href="color.css">
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">

    <title>Dashboard</title>
  </head>
  <body>
    <div class="container">
      <div class="row">
        <div class="col col-sm-12">
          <div class="alert alert-primary" role="alert">
            <h4> ยินดีต้อนรับ <?php echo $_SESSION["username"]; ?> </h4>
          </div>
        </div>
      </div>

      <div class="row">
        <div class="col-6 col-sm-4">
        <a href="pr-main.php">
          <div class="card text-black bg-light mb-4" style="max-width: 30rem;">
            <div class="card-header text-center"> 
              <ion-icon name="people-outline"></ion-icon>
                จำนวนใบสั่งซื้อของลูกค้าที่ยังไม่ได้ทำ 
            </div>
            <?php 
                $sql = "SELECT COUNT(id) as idstatezero FROM addpr WHERE status = '0' ";
                $query = $db_conn->query($sql);
                $fetch = mysqli_fetch_array($query);
          
                $po_count = $fetch['idstatezero'];
            ?>
            <div class="card-body">
              <h5 class="card-title text-center">
                <?php 
                    echo "จำนวน " . number_format($po_count) . " รายการ";
                ?>

              </h5>
              
            </div>
          </div>
          </a>
        </div>

        <?php if ($_SESSION['user_type'] == 'S'): ?>
        <div class="col-6 col-sm-4 hidden-btn">
          <a href="prfac-main.php">
          <div class="card text-black bg-light mb-4 " style="max-width: 30rem;">
            <div class="card-header text-center"> 
              <ion-icon name="cart-outline"></ion-icon>
              จำนวนใบต้นทุนที่รอตอบรับ
            </div>
            <?php 
                $sql = "SELECT COUNT(id) as idstatezero FROM addpo WHERE status = '0' ";
                $query = $db_conn->query($sql);
                $fetch = mysqli_fetch_array($query);

                $po_count = $fetch['idstatezero'];
            ?>
            <div class="card-body">
              <h5 class="card-title text-center">
                <?php 
                    echo "จำนวน " . number_format($po_count) . " รายการ";
                ?>

              </h5>
              
            </div>
          </div>
          </a>
        </div>   
        <?php endif; ?>
        <?php if ($_SESSION['user_type'] != 'S'): ?>
        <div class="col-6 col-sm-4">
          <a href="prfac-main.php">
          <div class="card text-black bg-light mb-4 " style="max-width: 30rem;">
            <div class="card-header text-center"> 
              <ion-icon name="cart-outline"></ion-icon>
              จำนวนใบต้นทุนที่รอตอบรับ
            </div>
            <?php 
                $sql = "SELECT COUNT(id) as idstatezero FROM addpo WHERE status = '0' ";
                $query = $db_conn->query($sql);
                $fetch = mysqli_fetch_array($query);

                $po_count = $fetch['idstatezero'];
            ?>
            <div class="card-body">
              <h5 class="card-title text-center">
                <?php 
                    echo "จำนวน " . number_format($po_count) . " รายการ";
                ?>

              </h5>
              
            </div>
          </div>
          </a>
        </div>   
        <?php endif; ?>
        
        <?php if ($_SESSION['user_type'] == 'S'): ?>
        <div class="col-6 col-sm-4 hidden-btn">
        <a href="po-main.php">
            <div class="card text-black bg-light mb-4" style="max-width: 30rem;">
                <div class="card-header text-center"> 
                    <ion-icon name="cart-outline"></ion-icon>
                    จำนวนใบสั่งซื้อของโรงงานที่สินค้ายังไม่ครบ
                </div>
                <?php 
                    $sql = "SELECT COUNT(id) as idstatezero FROM addpo WHERE status = '3' ";
                    $query = $db_conn->query($sql);
                    $fetch = mysqli_fetch_array($query);
                    $po_count = $fetch['idstatezero'];
                ?>
                <div class="card-body">
                    <h5 class="card-title text-center">
                        <?php 
                            echo "จำนวน " . number_format($po_count) . " รายการ";
                        ?>
                    </h5>
                </div>
            </div>
        </a>
        </div>
        <?php endif; ?>
        <?php if ($_SESSION['user_type'] != 'S'): ?>
        <div class="col-6 col-sm-4">
        <a href="po-main.php">
            <div class="card text-black bg-light mb-4" style="max-width: 30rem;">
                <div class="card-header text-center"> 
                    <ion-icon name="cart-outline"></ion-icon>
                    จำนวนใบสั่งซื้อของโรงงานที่สินค้ายังไม่ครบ
                </div>
                <?php 
                    $sql = "SELECT COUNT(id) as idstatezero FROM addpo WHERE status = '3' ";
                    $query = $db_conn->query($sql);
                    $fetch = mysqli_fetch_array($query);
                    $po_count = $fetch['idstatezero'];
                ?>
                <div class="card-body">
                    <h5 class="card-title text-center">
                        <?php 
                            echo "จำนวน " . number_format($po_count) . " รายการ";
                        ?>
                    </h5>
                </div>
            </div>
        </a>
        </div>
        <?php endif; ?>

      </div> 
    </div> 

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
    <script type="module" src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.esm.js"></script>
    <script nomodule src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.js"></script>
    <script>
document.addEventListener('DOMContentLoaded', function () {
    const form = document.getElementById('userForm');

    form.addEventListener('submit', function (event) {
        if (!form.checkValidity()) {
            event.preventDefault();
            event.stopPropagation();
        }

        form.classList.add('was-validated');
    }, false);
});
</script>
    <style>

    .dropdown-btn {
      color: #f1f1f1;
    }

    .dropdown-btn{
      text-decoration: none;
      font-size: 14px;
      font-weight: 500;
      padding: 8px 0;
      display: block;
      text-align: center;
      transition: color 0.3s ease;
      color: #818181;
      border: none;
      background: none;
      width: 100%;
      cursor: pointer;
      outline: none;
    }
    .hidden-btn {
      display: none;
    }
  </style>
  </body>
</html>
