<?php
require('../db_connect.php');
if(isset($_GET['nameId'])) {
    $searchValue = $_GET['nameId'];
    $positionValue = $_GET['position'];
    $statusValue = $_GET['status'];
    $query = "SELECT * FROM login WHERE (name LIKE '%$searchValue%' OR user_id LIKE '%$searchValue%')";
    if (!empty($positionValue)) {
        $query .= " AND (user = '$positionValue')";
    }
    if (!empty($statusValue)) {
        $query .= " AND (status = '$statusValue')";
    }
    $query_run = mysqli_query($db_conn, $query);
    
    if(mysqli_num_rows($query_run) > 0) {
        ?>
<thead>
    <tr class="text-center align-middle">
        <th>ลำดับที่</th>
        <th>ชื่อบัญชีผู้ใช้งาน</th>
        <th>ชื่อผู้ใช้</th>
        <th>ตำแหน่ง</th>
        <th>สถานะ</th>
        <th></th>
    </tr>
</thead>

<?php
        $i = 1;
        while($useraccount = mysqli_fetch_assoc($query_run)) {
            ?>
<tr class="align-middle">
    <td><?= $i; ?></td>
    <td><?= $useraccount['user_id']; ?></td>
    <td><?= $useraccount['name']; ?></td>
    <td>
        <?php
                    if ($useraccount['user'] == 'A') {
                        echo "Admin";
                    } elseif ($useraccount['user'] == 'P') {
                        echo "Procurement";
                    }elseif ($useraccount['user'] == 'S') {
                        echo "Sales Department";
                    }
                    ?>
    </td>
    <td>
        <?php
                    if ($useraccount['status'] == 0) {
                        echo "Active";
                    } elseif ($useraccount['status'] == 1) {
                        echo "Inactive";
                    }
                    ?>
    </td>
    <td>
        <?php if ($useraccount['status'] == 0): ?>
        <form action="User/user-submit.php" method="POST" class="d-inline">
            <button type="submit" name="active_user" value="<?= $useraccount['id']; ?>"
                class="btn btn-primary btn-sm hidden-btn">active</button>
        </form>
        <?php elseif ($useraccount['status'] == 1): ?>
        <form action="User/user-submit.php" method="POST" class="d-inline">
            <button type="submit" name="active_user" value="<?= $useraccount['id']; ?>"
                class="btn btn-primary btn-sm">active</button>
        </form>
        <?php endif; ?>
        <?php if ($useraccount['status'] == 0): ?>
        <form action="User/user-submit.php" method="POST" class="d-inline">
            <button type="submit" name="delete_user" value="<?= $useraccount['id']; ?>"
                class="btn btn-danger btn-sm">Delete</button>
        </form>
        <?php elseif ($useraccount['status'] == 1): ?>
        <form action="User/user-submit.php" method="POST" class="d-inline">
            <button type="submit" name="delete_user" value="<?= $useraccount['id']; ?>"
                class="btn btn-danger btn-sm hidden-btn">Delete</button>
        </form>
        <?php endif; ?>
    </td>
</tr>
<?php
            $i++;
        }
    } else {
        echo '<tr class="text-center"><td colspan="6">ไม่พบบัญชีผู้ใช้งาน</td></tr>';

    }
}
?>