<?php
session_start();
require '../db_connect.php';

if (isset($_POST['update_user'])) {
    $user_id = mysqli_real_escape_string($db_conn, $_POST['user_id']);
    $name = mysqli_real_escape_string($db_conn, $_POST['name']);
    $password = mysqli_real_escape_string($db_conn, $_POST['password']);
    $confirm_password = mysqli_real_escape_string($db_conn, $_POST['confirm_password']);

    if ($password === $confirm_password) {
        if (!empty($password)) {
            $hashed_password = password_hash($password, PASSWORD_DEFAULT);
            $update_query = "UPDATE login SET name='$name', password='$hashed_password' WHERE id='$user_id'";
        } else {
            $update_query = "UPDATE login SET name='$name' WHERE id='$user_id'";
        }

        if (mysqli_query($db_conn, $update_query)) {
            $_SESSION['msg_type'] = "success";
            $_SESSION['message'] = "ปรับปรุงสำเร็จ";
        } else {
            $_SESSION['msg_type'] = "danger";
            $_SESSION['message'] = "ปรับปรุงไม่สำเร็จ";
        }
    } else {
        $_SESSION['msg_type'] = "danger";
        $_SESSION['message'] = "รหัสผ่านไม่ตรงกัน กรุณาลองใหม่";
    }

    header("Location: ../Logout.php");
    exit(0);
}

if (isset($_POST['delete_user'])) {
    $user_id = mysqli_real_escape_string($db_conn, $_POST['delete_user']);

    $query = "UPDATE login SET status = 1 WHERE id='$user_id'";
    $query_run = mysqli_query($db_conn, $query);

    if ($query_run) {
        $_SESSION['msg_type'] = "success";
        $_SESSION['message'] = "ปรับปรุงสำเร็จ";
    } else {
        $_SESSION['msg_type'] = "danger";
        $_SESSION['message'] = "ปรับปรุงไม่สำเร็จ";
    }

    header("Location: ../user-main.php");
    exit(0);
}

if (isset($_POST['active_user'])) {
    $user_id = mysqli_real_escape_string($db_conn, $_POST['active_user']);

    $query = "UPDATE login SET status = 0 WHERE id='$user_id'";
    $query_run = mysqli_query($db_conn, $query);

    if ($query_run) {
        $_SESSION['msg_type'] = "success";
        $_SESSION['message'] = "ปรับปรุงสำเร็จ";
    } else {
        $_SESSION['msg_type'] = "danger";
        $_SESSION['message'] = "ปรับปรุงไม่สำเร็จ";
    }

    header("Location: ../user-main.php");
    exit(0);
}
?>
