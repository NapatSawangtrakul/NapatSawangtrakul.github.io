<?php  
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/factory.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <title>เพิ่มบัญชีผู้ใช้งาน</title>
</head>
<body>
    <div class="container-fluid mt-4 custom-container">
    <?php include('../message.php'); ?>
    <?php
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        require_once("../db_connect.php");
    
        $userid = $_POST["userid"];
        $fullname = $_POST["fullname"];
        $password = $_POST["password"];
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);
        $status = $_POST["level"];
    
        $sql = "INSERT INTO login (userid, fullname, password, levels) ";
        $sql .= "VALUES ('$userid', '$fullname', '$hashed_password', '$status');";
    
        if ($db_conn->query($sql) === FALSE) {
            echo "<div class='alert alert-danger'>บันทึกไม่สำเร็จ</div>";
            $db_conn->close();
        } else {
            echo "<div class='alert alert-success'>บันทึกสำเร็จ</div>";
            $db_conn->close();
            echo "<meta http-equiv='refresh' content='2;url=/User/user-main.php'>";
            exit();
        }
    }    
    ?>
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <h4>เพิ่มบัญชีผู้ใช้งาน
                        <a href="../user-main.php" class="btn btn-danger float-end">กลับหน้าหลัก</a>
                    </h4>
                </div>
                <form action="user-process.php" method="post" id="userForm" novalidate>
                    <div class="card-body">
                        <div class="mb-3">
                            <label for="userid" class="form-label">ชื่อบัญชีผู้ใช้งาน <span style="color: red;">*</span></label>
                            <input type="text" class="form-control border border-secondary" name="userid" id="userid" required>
                            <div class="invalid-feedback">
                                กรุณากรอกชื่อบัญชีผู้ใช้งาน
                            </div>
                        </div>
                        <div class="mb-3">
                            <label for="fullname" class="form-label">ชื่อ-นามสกุลผู้ใช้ <span style="color: red;">*</span></label>
                            <input type="text" class="form-control border border-secondary" name="fullname" id="fullname" required>
                            <div class="invalid-feedback">
                                กรุณากรอกชื่อผู้ใช้
                            </div>
                        </div>
                        <div class="mb-3">
                        <label for="password" class="form-label">รหัสผ่าน <span style="color: red;">*</span></label>
                            <input type="password" class="form-control border border-secondary" name="password" id="password" required>
                            <div class="invalid-feedback">
                                กรุณากรอกรหัสผ่าน
                            </div>
                        </div>
                        <div class="mb-3">
                            <label for="level" class="form-label">ตำแหน่ง <span style="color: red;">*</span></label>
                            <select name="level" id="level" class="form-control border border-secondary" required>
                                <option value="">-- เลือกตำแหน่ง --</option>
                                <option value="A">Admin</option>
                                <option value="P">Purchase</option>
                                <option value="S">Sales Department</option>
                            </select>
                            <div class="invalid-feedback">
                                กรุณาเลือกตำแหน่ง
                            </div>
                        </div>
                        <div class="mb-3">
                        <label for="linetoken" class="form-label">Linetokenผู้ใช้งาน</label>
                            <input type="linetoken" class="form-control border border-secondary" name="linetoken" id="linetoken">
                        </div>
                        <div class="mb-3 text-center">
                            <button type="submit" name="signup" class="btn btn-primary">เพิ่มบัญชี</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
<script>
document.addEventListener('DOMContentLoaded', function () {
    const form = document.getElementById('userForm');

    form.addEventListener('submit', function (event) {
        if (!form.checkValidity()) {
            event.preventDefault();
            event.stopPropagation();
        }

        form.classList.add('was-validated');
    }, false);
});
</script>

<style>
input[type="linetoken"] {
    font-family: "Arial", sans-serif;
    color: #000000;
    padding: 10px;
    margin: 10px;
    border: none;
    box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.2);
    border-radius: 5px;
}
.custom-container {
    margin-left: 100px;
    margin-right: 100px;
}
</style>
</body>
</html>
