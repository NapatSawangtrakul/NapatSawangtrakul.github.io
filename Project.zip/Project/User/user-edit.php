<?php
session_start();
require '../db_connect.php';

if (isset($_GET['id'])) {
    $user_id = mysqli_real_escape_string($db_conn, $_GET['id']);
    
    $query = "SELECT * FROM login WHERE id='$user_id'";
    $query_run = mysqli_query($db_conn, $query);

    if (mysqli_num_rows($query_run) > 0) {
        $user = mysqli_fetch_array($query_run);
    } else {
        echo "<h4>ไม่พบข้อมูล</h4>";
    }
} else {
    echo "<h4>ไม่พบข้อมูล</h4>";
}
?>

<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>แก้ไขข้อมูลผู้ใช้งาน</title>
    <link rel="stylesheet" href="../css/factory.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container-fluid mt-4 custom-container">
    <?php include('../message.php'); ?>
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <h4>แก้ไขข้อมูลผู้ใช้งาน
                        <a href="../main_menu.php" class="btn btn-danger float-end">กลับหน้าหลัก</a>
                    </h4>
                </div>
                <div class="card-body">
                    <?php if (isset($user)) { ?>
                        <form action="user-submit.php" method="POST" onsubmit="return validatePassword()">
                            <input type="hidden" name="user_id" value="<?= $user['id']; ?>">
                            <div class="mb-3">
                                <label>ชื่อ-นามสกุลผู้ใช้งาน</label>
                                <input type="text" name="name" value="<?= $user['name']; ?>" class="form-control border border-secondary">
                            </div>
                            <div class="mb-3">
                                <label>Linetokenผู้ใช้งาน</label>
                                <input type="linetoken" name="linetoken" id="linetoken" class="form-control border border-secondary">
                            </div>
                            <div class="mb-3">
                                <label>รหัสผ่านใหม่</label>
                                <input type="password" name="password" id="password" class="form-control border border-secondary">
                            </div>
                            <div class="mb-3">
                                <label>ยืนยันรหัสผ่าน</label>
                                <input type="password" name="confirm_password" id="confirm_password" class="form-control border border-secondary">
                            </div>
                            <div class="mb-3">
                                <button type="submit" name="update_user" class="btn btn-primary">บันทึก</button>
                            </div>
                        </form>
                    <?php } ?>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
<script>
function validatePassword() {
    var password = document.getElementById("password").value;
    var confirmPassword = document.getElementById("confirm_password").value;

    if (password !== confirmPassword) {
        alert("รหัสผ่านไม่ตรงกัน กรุณาลองใหม่");
        return false;
    }
    return true;
}
</script>
<style>
    input[type="linetoken"] {
    font-family: "Arial", sans-serif;
    color: #000000;
    padding: 10px;
    margin: 10px;
    border: none;
    box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.2);
    border-radius: 5px;
}
.custom-container {
            margin-left: 100px;
            margin-right: 100px;
        }
</style>
</body>
</html>
