<?php 
session_start();

require_once "../db_connect.php";

if (isset($_POST['signup']))
{
    $user_id = $_POST['userid'];
    $fullname = $_POST['fullname'];
    $password = $_POST['password'];
    $line = $_POST['linetoken'];
    $ulevel = $_POST['level'];

    $check_userid = "SELECT * FROM login WHERE user_id = '$user_id' LIMIT 1";
    $result = mysqli_query($db_conn, $check_userid);

    if (mysqli_num_rows($result) > 0)
    {
        echo "<script>alert('มีบัญชีผู้ใช้งานอยู่แล้ว'); window.location.href = 'user-create.php';</script>";
    }
    else
    {
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);
        $sql = "INSERT INTO login (user_id, name, password, user, linetoken) VALUES ('$user_id', '$fullname', '$hashed_password', '$ulevel', '$line')";
        
        if (mysqli_query($db_conn, $sql))
        {
            $_SESSION['success'] = "เพิ่มบัญชีผู้ใช้สำเร็จ";
            echo "<script>alert('เพิ่มบัญชีผู้ใช้สำเร็จ'); window.location.href = '../user-main.php';</script>";
        }
        else
        {
            $_SESSION['error'] = "เพิ่มบัญชีผู้ใช้ไม่สำเร็จ";
            echo "<script>alert('เพิ่มบัญชีผู้ใช้ไม่สำเร็จ'); window.location.href = 'user-create.php';</script>";
        }
    }
}
?>
