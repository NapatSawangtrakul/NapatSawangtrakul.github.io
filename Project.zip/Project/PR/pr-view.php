<?php
session_start();
require('../db_connect.php');

if (isset($_GET['id'])) {
    $id = mysqli_real_escape_string($db_conn, $_GET['id']);
    $query = "SELECT * FROM addpr WHERE id = '$id'";
    $result = mysqli_query($db_conn, $query);

    if (mysqli_num_rows($result) == 1) {
        $pr = mysqli_fetch_assoc($result);
    } else {
        $_SESSION['message'] = "ไม่พบ PR";
        header("Location: ../pr-main.php");
        exit();
    }
} else {
    $_SESSION['message'] = "ไม่พบ PR";
    header("Location: ../pr-main.php");
    exit();
}
?>

<!Doctype html>
<html lang="th">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/factory.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/html2canvas/1.4.1/html2canvas.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <title>รายละเอียดใบสั่งซื้อของลูกค้า</title>
</head>

<body>
    <div class="container-fluid mt-4 custom-container">
        <?php include('../message.php'); ?>

        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <h4>รายละเอียดใบสั่งซื้อของลูกค้า
                            <a href="../pr-main.php" class="btn btn-danger float-end">กลับหน้าหลัก</a>
                            <?php if ($_SESSION['user_type'] == 'S'): ?>
                            <button class="btn btn-primary float-end" onclick="generatePDF(<?= $pr['id']; ?>)">พิมพ์ PDF</button>
                            <?php endif; ?>
                        </h4>
                    </div>
                    <div class="card-body print-container">
                        <?php
                        $query = mysqli_query($db_conn, "SELECT * FROM mf");

                        while ($row = mysqli_fetch_array($query)) {
                        ?>
                        <div class="form">
                            <table class="table">
                                <tr>
                                    <td>
                                        <h3><?php echo $row['nameTH']; ?></h3>
                                        <h3><?php echo $row['nameEN']; ?></h3>
                                        <h5><?php echo $row['locationTH']; ?></h5>
                                        <h5><?php echo $row['locationEN']; ?></h5>
                                        <h5>Tel : <?php echo $row['phone']; ?></h5>
                                    </td>
                                    <td>
                                        <h3>Purchase Request</h3>
                                        <h5 class="mt-4">เลขที่เอกสาร PR : <?= $pr['pr']; ?></h5>
                                        <h5>วันที่ : <?= date('d/m/Y', strtotime($pr['date_created'])); ?></h5>
                                        <h5 for="namecustomer" class="form-label">ชื่อลูกค้า :
                                            <?= $pr['namecustomer']; ?></h5>
                                        <h5 for="phonecustomer" class="form-label">เบอร์โทรศัพท์ลูกค้า :
                                            <?= $pr['phone']; ?></h5>
                                    </td>
                                </tr>
                            </table>
                        </div>
                        <?php
                        }
                        ?>

                        <table class="table table-bordered">
                            <thead>
                                <tr class="text-center align-middle">
                                    <th>รหัสสินค้า-ชื่อสินค้า</th>
                                    <th>จำนวนสินค้า(แผ่น)</th>
                                    <?php
                                    $itemListInsQuery = "SELECT * FROM itemlistfac WHERE pr_id = ? AND price IS NOT NULL";
                                    $itemListInsStmt = $db_conn->prepare($itemListInsQuery);
                                    $itemListInsStmt->bind_param("s", $pr['pr']);
                                    $itemListInsStmt->execute();
                                    $itemListInsResult = $itemListInsStmt->get_result();

                                    if ($itemListInsResult->num_rows > 0) {
                                    ?>
                                    <th>ราคาสินค้าต่อหน่วย(บาท)</th>
                                    <th>ราคารวม(บาท)</th>
                                    <?php
                                    }
                                    ?>
                                </tr>
                            </thead>
                            <tbody class="align-middle">
                                <?php
                                    $prNumber = $pr['pr'];
                                    $itemListInsQuery = "SELECT * FROM itemlistfac WHERE pr_id = ?";
                                    $itemListInsStmt = $db_conn->prepare($itemListInsQuery);
                                    $itemListInsStmt->bind_param("s", $prNumber);
                                    $itemListInsStmt->execute();
                                    $itemListInsResult = $itemListInsStmt->get_result();

                                    $totalPrice = 0;
                                    $VAT = 0;
                                    if ($itemListInsResult->num_rows > 0) {
                                        while ($item = $itemListInsResult->fetch_assoc()) {
                                            $itemTotal = $item['quantity'] * $item['price'];
                                            $totalPrice += $itemTotal;
                                    ?>
                                <tr>
                                    <td><?= $item['idpro_id']; ?> - <?= $item['namepro']; ?></td>
                                    <td class="text-center"><?= number_format($item['quantity'], 0); ?></td>
                                    <td class="text-end"><?= number_format($item['price'], 2); ?></td>
                                    <td class="text-end"><?= number_format($itemTotal, 2); ?></td>

                                </tr>
                                <?php
                                        }
                                        $VAT = $totalPrice * 0.07;
                                        $totalWithVAT = $totalPrice + $VAT;
                                        echo "<tr>
                                        <td colspan='2' style='border: 0;'></td>
                                        <td>รวมเป็นเงิน</td>
                                        <td class='text-end'>" . number_format($totalPrice, 2) . "</td>
                                    </tr>";
                                
                                    } else {
                                        $itemListQuery = "SELECT * FROM itemlist WHERE pr_id = ?";
                                        $itemListStmt = $db_conn->prepare($itemListQuery);
                                        $itemListStmt->bind_param("s", $prNumber);
                                        $itemListStmt->execute();
                                        $itemListResult = $itemListStmt->get_result();

                                        if ($itemListResult->num_rows > 0) {
                                            while ($item = $itemListResult->fetch_assoc()) {
                                    ?>
                                <tr>
                                    <td><?= $item['idpro_id']; ?> - <?= $item['namepro']; ?></td>
                                    <td><?= number_format($item['quantity'], 0); ?></td>
                                </tr>
                                <?php
                                            }
                                        } else {
                                            echo "<tr><td colspan='4'>ไม่พบรายการสินค้า</td></tr>";
                                        }
                                    }
                                    ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
<script>
    async function generatePDF(id) {
        var {
            jsPDF
        } = window.jspdf;
        var content = document.getElementById('print-content');

        await html2canvas(content, {
            scale: 2
        }).then((canvas) => {
            var imgData = canvas.toDataURL('image/png');
            var pdf = new jsPDF('p', 'pt', 'a4');
            var imgWidth = 595.28;
            var pageHeight = 841.89;
            var imgHeight = canvas.height * imgWidth / canvas.width;
            var heightLeft = imgHeight;
            var position = 0;

            pdf.addImage(imgData, 'PNG', 0, position, imgWidth, imgHeight);
            heightLeft -= pageHeight;

            while (heightLeft >= 0) {
                position = heightLeft - imgHeight;
                pdf.addPage();
                pdf.addImage(imgData, 'PNG', 0, position, imgWidth, imgHeight);
                heightLeft -= pageHeight;
            }

            var filename = 'ใบสั่งซื้อของลูกค้า ' + '<?= $pr['pr']; ?>' + '.pdf';
            pdf.save(filename);
        });

        var xhr = new XMLHttpRequest();
        xhr.open('GET', 'pr-print.php?id=' + id, true);
        xhr.onreadystatechange = function() {
            if (xhr.readyState === XMLHttpRequest.DONE && xhr.status === 200) {
                window.location.href = '../pr-view.php';
            }
        };
        xhr.send();
    }
</script>
    <style>
    .custom-container {
        margin-left: 100px;
        margin-right: 100px;
    }

    @media print {
        .print-hidden {
            display: none;
        }

        .hidden-btn {
            display: none;
        }
    }
    </style>
</body>

</html>