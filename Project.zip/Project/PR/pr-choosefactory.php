<?php
session_start();
require '../db_connect.php';

if (isset($_GET['id'])) {
    $id = mysqli_real_escape_string($db_conn, $_GET['id']);
    $query = "SELECT * FROM addpr WHERE id = ?";
    $stmt = $db_conn->prepare($query);
    $stmt->bind_param("s", $id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows == 1) {
        $pr = $result->fetch_assoc();
    } else {
        $_SESSION['message'] = "ไม่พบ PR";
        header("Location: ../pr-main.php");
        exit();
    }
} else {
    $_SESSION['message'] = "ไม่พบ PR";
    header("Location: ../pr-main.php");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $prNumber = $pr['pr'];
    $nameCustomer = $pr['namecustomer'];
    $phoneCustomer = $pr['phone'];
    
    $itemListQuery = "SELECT * FROM itemlist WHERE pr_id = ?";
    $itemListStmt = $db_conn->prepare($itemListQuery);
    $itemListStmt->bind_param("s", $prNumber);
    $itemListStmt->execute();
    $itemListResult = $itemListStmt->get_result();

    $selectedFactoriesData = [];
    $error = false;
    $missingSelections = [];

    foreach ($itemListResult as $item) {
        $idpro_id = $item['idpro_id'];

        if (isset($_POST['factory_selection'][$idpro_id])) {
            $selectedFactory = $_POST['factory_selection'][$idpro_id];
            $namepro = $item['namepro'];
            $price = $item['price'];
            $quantity = $item['quantity'];

            $selectedFactoriesData[$selectedFactory][] = [
                'idpro_id' => $idpro_id,
                'namepro' => $namepro,
                'price' => $price,
                'quantity' => $quantity,
            ];
        } else {
            $error = true;
            $missingSelections[] = $item['namepro'];
        }
    }

    if ($error) {
        $_SESSION['message'] = "กรุณาเลือกโรงงานสำหรับสินค้าดังต่อไปนี้: " . implode(', ', $missingSelections);
        header("Location: pr-choosefactory.php?id=$id");
        exit();
    }

    foreach ($selectedFactoriesData as $selectedFactory => $data) {
        $checkQuery = "SELECT * FROM addprfac WHERE pr = ? AND namecustomer = ? AND namefac = ?";
        $checkStmt = $db_conn->prepare($checkQuery);
        $checkStmt->bind_param("sss", $prNumber, $nameCustomer, $selectedFactory);
        $checkStmt->execute();
        $checkResult = $checkStmt->get_result();

        if ($checkResult->num_rows === 0) { 
            $insertQuery = "INSERT INTO addprfac (date_created, pr, namecustomer, phone, namefac, status) VALUES (NOW(), ?, ?, ?, ?, 0)";
            $insertStmt = $db_conn->prepare($insertQuery);
            $insertStmt->bind_param("ssss", $prNumber, $nameCustomer, $phoneCustomer, $selectedFactory);
            $insertStmt->execute();

            foreach ($data as $itemData) {
                $insertQuery = "INSERT INTO itemlistfac (pr_id, idpro_id, namepro, price, quantity, namefac) VALUES (?, ?, ?, ?, ?, ?)";
                $insertStmt = $db_conn->prepare($insertQuery);
                $insertStmt->bind_param("ssssss", $prNumber, $itemData['idpro_id'], $itemData['namepro'], $itemData['price'], $itemData['quantity'], $selectedFactory);
                $insertStmt->execute();
            }
        }
    }
    
    $updateStatusQuery = "UPDATE addpr SET status = 1 WHERE pr = ?";
    $updateStatusStmt = $db_conn->prepare($updateStatusQuery);
    $updateStatusStmt->bind_param("s", $prNumber);
    $updateStatusStmt->execute();
    header("Location: ../pr-main.php");
    exit();
}
?>

<!doctype html>
<html lang="th">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/factory.css">
    <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.1.0/css/select2.min.css" rel="stylesheet">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/jquery@3.5.1/dist/jquery.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.1.0/js/select2.min.js"></script>
    <title>รายละเอียดใบสั่งซื้อของลูกค้า</title>
</head>
<body>
    <div class="container-fluid mt-4 custom-container">
        <?php include('../message.php'); ?>
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <h4>รายละเอียดใบสั่งซื้อของลูกค้า
                            <a href="../pr-main.php" class="btn btn-danger float-end">กลับหน้าหลัก</a>
                        </h4>
                    </div>
                    <div class="card-body">
                        <form action="pr-choosefactory.php?id=<?= $id ?>" method="POST">
                            <?php
                            $query = mysqli_query($db_conn, "SELECT * FROM mf");

                            while ($row = mysqli_fetch_array($query)) {
                            ?>
                            <div class="form">
                                <table class="table">
                                    <tr>
                                        <td>
                                            <h3><?php echo $row['nameTH']; ?></h3>
                                            <h3><?php echo $row['nameEN']; ?></h3>
                                            <h5><?php echo $row['locationTH']; ?></h5>
                                            <h5><?php echo $row['locationEN']; ?></h5>
                                            <h5>Tel : <?php echo $row['phone']; ?></h5>
                                        </td>
                                        <td>
                                            <h3>Purchase Request</h3>
                                            <h5 class="mt-4">เลขที่เอกสาร PR : <?= $pr['pr']; ?></h5>
                                            <h5>วันที่ : <?= date('d/m/Y', strtotime($pr['date_created'])); ?></h5>
                                            <h5 for="namecustomer" class="form-label">ชื่อลูกค้า : <?= $pr['namecustomer']; ?></h5>
                                            <h5 for="phonecustomer" class="form-label">เบอร์โทรศัพท์ลูกค้า : <?= $pr['phone']; ?></h5>
                                        </td>
                                    </tr>
                                </table>
                            </div>
                            <?php
                            }
                            ?>

                            <table class="table table-bordered">
                                <thead>
                                    <tr class="text-center">
                                        <th>รหัสสินค้า-ชื่อสินค้า</th>
                                        <th>จำนวนสินค้า(แผ่น)</th>
                                        <th>
                                            เลือกโรงงาน
                                            <button type="button" class="btn btn-info btn-sm" data-bs-toggle="modal" data-bs-target="#infoModal">
                                                i
                                            </button>


                                        </th>
                                    </tr>
                                </thead>
                                <tbody>
    <?php
    $itemListQuery = "SELECT * FROM itemlist WHERE pr_id = ?";
    $itemListStmt = $db_conn->prepare($itemListQuery);
    $itemListStmt->bind_param("s", $pr['pr']);
    $itemListStmt->execute();
    $itemListResult = $itemListStmt->get_result();

    if ($itemListResult->num_rows > 0) {
        while ($item = $itemListResult->fetch_assoc()) {
            $idpro_id = $item['idpro_id'];
            $selectedFactoryForRow = isset($factorySelection[$idpro_id]) ? $factorySelection[$idpro_id] : '';
            ?>
            <tr>
                <td><?= $item['idpro_id']; ?> - <?= $item['namepro']; ?></td>
                <td class="text-center"><?= $item['quantity']; ?></td>
                <td class="text-center align-middle tda">
                    <select name="factory_selection[<?= $item['idpro_id']; ?>]" class="form-control select2 mb-3">
                        <option value="" disabled <?= empty($selectedFactoryForRow) ? "selected" :'' ?>></option>
                        <?php 
                        $factory_qry = $db_conn->query("SELECT * FROM `factory` ORDER BY `Name` ASC");
                        while ($row = $factory_qry->fetch_assoc()):
                            $selected = $row['id'] == $selectedFactoryForRow ? 'selected' : '';
                            $disabled = $row['Status'] == 0 ? 'disabled' : '';
                        ?>
                        <option value="<?= $row['id'] ?>" <?= $selected ?> <?= $disabled ?>><?= $row['Name'] ?></option>
                        <?php endwhile; ?>
                    </select>
                </td>
            </tr>
            <?php
        }
    } else {
        echo "<tr><td colspan='3'>ไม่พบรายการสินค้า</td></tr>";
    }
    ?>
</tbody>

                            </table>
                            <input type="submit" class="btn btn-primary" value="บันทึก">
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="modal fade" id="infoModal" tabindex="-1" aria-labelledby="infoModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="infoModalLabel">ข้อมูลราคาต้นทุนสินค้า</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div id="messageBox"></div>
            </div>
        </div>
    </div>
    </div>

<script>
    $('#infoModal').on('show.bs.modal', function (event) {
    var button = $(event.relatedTarget);
    var modal = $(this);
    var messageBox = modal.find('#messageBox');

    $.ajax({
        url: 'tooltip.php',
        method: 'GET',
        success: function(data) {
            messageBox.empty();
            if (data.message) {
                messageBox.html(`<p>${data.message}</p>`);
            } else {
                var groupedData = data.reduce(function (acc, row) {
                    if (!acc[row.namefac]) {
                        acc[row.namefac] = [];
                    }
                    acc[row.namefac].push(row);
                    return acc;
                }, {});

                for (var factory in groupedData) {
                    messageBox.append(`<h5>ชื่อโรงงาน: ${factory}</h5>`);
                    groupedData[factory].forEach(function (row) {
                        messageBox.append(`<p>${row.pr_id} ${row.po_id} ${row.idpro_id} - ${row.namepro} ราคา: ${row.price} จำนวน: ${row.quantity}</p>`);
                    });
                    messageBox.append('<hr>');
                }
            }
        },
        error: function(xhr, status, error) {
            messageBox.html(`<p class="text-danger">เกิดข้อผิดพลาดในการดึงข้อมูล: ${error}</p>`);
        }
    });
});

$(document).ready(function() {
    $('.select2').select2();
});
</script>
<style>
    #tooltip {
        border: 1px solid #ccc;
        padding: 10px;
        background-color: #f9f9f9;
        width: 200px;
    }
    .message-box {
        display: none;
        position: absolute;
        padding: 10px;
        background-color: #F0FFFF;
        color: #000;
        border: 1px solid #000;
    }
    .tda {
        border: 1px solid black;
        width: 50%;
    }
    .modal-body {
        max-height: 400px;
        overflow-y: auto;
    }
    .modal-lg {
        max-width: 80%;
    }
    .modal-body p {
        margin: 0;
    }
    .modal-body hr {
        margin-top: 10px;
        margin-bottom: 10px;
    }
    .custom-container {
            margin-left: 100px;
            margin-right: 100px;
        }
</style>

</body>
</html>
