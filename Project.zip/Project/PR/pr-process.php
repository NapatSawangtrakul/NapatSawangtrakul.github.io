<?php
require_once("../db_connect.php");

if ($db_conn->connect_error) {
    die("Connection failed: " . $db_conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nameCMs = $_POST['namecustomer'];
    $phoneCMs = $_POST['phone'];
    $products = $_POST['product'];
    $quantities = $_POST['quantity'];

    $getLastPRNumberSql = "SELECT pr FROM addpr ORDER BY id DESC LIMIT 1";
    $lastPRNumberResult = $db_conn->query($getLastPRNumberSql);
    $lastPRNumber = 0;

    if ($lastPRNumberResult && $lastPRNumberResult->num_rows > 0) {
        $lastPRNumberRow = $lastPRNumberResult->fetch_assoc();
        $lastPRNumber = intval(substr($lastPRNumberRow['pr'], 3)); 
    }

    $nextPRNumber = "PR-" . str_pad($lastPRNumber + 1, 4, '0', STR_PAD_LEFT);

    $db_conn->begin_transaction();

    $sql = "INSERT INTO addpr (namecustomer, phone, pr) VALUES (?, ?, ?)";
    $stmt = $db_conn->prepare($sql);

    $sql1 = "INSERT INTO itemlist (idpro_id, namepro, quantity, pr_id) VALUES (?, ?, ?, ?)";
    $s = $db_conn->prepare($sql1);

    if ($stmt && $s) {
        $stmt->bind_param("sss", $nameCMs, $phoneCMs, $nextPRNumber);
        $stmt->execute();

        $s->bind_param("ssss", $productId, $productName, $quantity, $nextPRNumber);

        foreach ($products as $index => $product) {
            $quantity = $quantities[$index];
            $productSql = "SELECT namepro FROM product WHERE idpro = ?";
            $productStmt = $db_conn->prepare($productSql);
            $productStmt->bind_param("s", $product);
            $productStmt->execute();
            $productResult = $productStmt->get_result();
            if ($productResult && $productResult->num_rows > 0) {
                $productRow = $productResult->fetch_assoc();
                $productName = $productRow['namepro'];
            } else {
                $productName = "ไม่พบรายการสินค้า";
            }
            $productStmt->close();

            $productId = $product;
            $s->execute();
        }

        $db_conn->commit();

        $sToken = "pZtWSchZ2LSvdh4MKppmuvilWIZyzsE5sky2FkQ6USo";
        $sMessage = "มีใบสั่งซื้อของลูกค้ามาใหม่ " . $nextPRNumber . " " . $nameCMs;

        $chOne = curl_init(); 
        curl_setopt( $chOne, CURLOPT_URL, "https://notify-api.line.me/api/notify"); 
        curl_setopt( $chOne, CURLOPT_SSL_VERIFYHOST, 0); 
        curl_setopt( $chOne, CURLOPT_SSL_VERIFYPEER, 0); 
        curl_setopt( $chOne, CURLOPT_POST, 1); 
        curl_setopt( $chOne, CURLOPT_POSTFIELDS, "message=".$sMessage); 
        $headers = array( 'Content-type: application/x-www-form-urlencoded', 'Authorization: Bearer '.$sToken.'', );
        curl_setopt($chOne, CURLOPT_HTTPHEADER, $headers); 
        curl_setopt( $chOne, CURLOPT_RETURNTRANSFER, 1); 
        $result = curl_exec( $chOne );

        header("Location: ../pr-main.php");
    } else {
        $db_conn->rollback();
        echo "Error preparing statement: " . $db_conn->error;
    }

    $stmt->close();
    $s->close();
} else {
    echo "Invalid request.";
}
   
$db_conn->close();
?>
