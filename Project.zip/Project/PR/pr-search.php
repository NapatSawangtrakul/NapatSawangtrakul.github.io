<?php
session_start();
require('../db_connect.php');

$dateFrom = $_GET['date_from'] ?? '';
$dateTo = $_GET['date_to'] ?? '';
$customer = $_GET['namecustomer'] ?? '';
$status = $_GET['status'] ?? '';

$condition = "1";
if (!empty($dateFrom) && !empty($dateTo)) {
    $condition .= " AND date_created BETWEEN ? AND ?";
}

if (!empty($customer)) {
    $condition .= " AND (namecustomer LIKE ? OR pr LIKE ?)";
}

if ($status !== '') {
    $condition .= " AND status = ?";
}

$results_per_page = 10;
$page = $_GET['page'] ?? 1;
$this_page_first_result = ($page - 1) * $results_per_page;

$query = "SELECT * FROM addpr WHERE $condition ORDER BY pr DESC LIMIT ?, ?";
$stmt = $db_conn->prepare($query);

$params = [];
$types = '';

if (!empty($dateFrom) && !empty($dateTo)) {
    $params[] = $dateFrom;
    $params[] = $dateTo;
    $types .= 'ss';
}

if (!empty($customer)) {
    $params[] = "%$customer%";
    $params[] = "%$customer%";
    $types .= 'ss';
}

if ($status !== '') {
    $params[] = $status;
    $types .= 's';
}

$params[] = $this_page_first_result;
$params[] = $results_per_page;
$types .= 'ii';

$stmt->bind_param($types, ...$params);

$stmt->execute();
$result = $stmt->get_result();
$i = 1;

if ($result->num_rows > 0) {
    while ($pr = $result->fetch_assoc()) {
        echo '<tr class="align-middle">';
        echo '<td>' . $i . '</td>';
        echo '<td>' . date("d/m/Y", strtotime($pr['date_created'])) . '</td>';
        echo '<td>' . $pr['pr'] . '</td>';
        echo '<td>' . $pr['namecustomer'] . '</td>';

        $phone = $pr['phone'];
        if (strlen($phone) == 10) {
            $formattedPhone = substr($phone, 0, 3) . '-' . substr($phone, 3, 3) . '-' . substr($phone, 6);
        } else {
            $formattedPhone = $phone;
        }
        echo '<td>' . $formattedPhone . '</td>';

        echo '<td>';

        if ($pr['status'] == 0) {
            echo '<span style="color:#080808;">ยังไม่ได้ดำเนินการ</span>';
        } elseif ($pr['status'] == 1) {
            echo '<span style="color:#080808;">ดำเนินการเรียบร้อย</span>';
        } elseif ($pr['status'] == 2) {
            echo '<span style="color:#080808;">ยกเลิกดำเนินการ</span>';
        } elseif ($pr['status'] == 3) {
            echo '<span style="color:#080808;">ข้อมูลยังไม่ครบ</span>';
        } elseif ($pr['status'] == 4) {
            echo '<span style="color:#080808;">ข้อมูลครบ</span>';
        }

        echo '</td>';
        echo '<td class="text-center align-middle">';
        echo '<div class="d-flex align-items-center">';
        echo '<a href="PR/pr-view.php?id=' . $pr['id'] . '" class="btn btn-info btn-sm">View</a>';

        if ($pr['status'] == 0 && $_SESSION['user_type'] == 'S') {
            echo '<a href="PR/pr-edit.php?id=' . $pr['id'] . '" class="btn btn-success btn-sm">edit</a>';
        } elseif (($pr['status'] != 0) && $_SESSION['user_type'] != 'S') {
            echo '<a href="PR/pr-edit.php?id=' . $pr['id'] . '" class="btn btn-success btn-sm hidden-btn">edit</a>';
        }

        if ($pr['status'] == 0 && $_SESSION['user_type'] != 'S') {
            echo '<a href="PR/pr-edit.php?id=' . $pr['id'] . '" class="btn btn-success btn-sm">Factory select</a>';
        } elseif ($pr['status'] != 0 && $_SESSION['user_type'] != 'S') {
            echo '<a href="PR/pr-edit.php?id=' . $pr['id'] . '" class="btn btn-success btn-sm hidden-btn">Factory select</a>';
        }

        if ($pr['status'] == 4 && $_SESSION['user_type'] == 'S') {
            echo '<a href="PR/export_csv.php?id=' . $pr['id'] . '" class="btn btn-success btn-sm float-end">Export CSV</a>';
        } elseif ($pr['status'] != 4 && $_SESSION['user_type'] != 'S') {
            echo '<a href="PR/export_csv.php?id=' . $pr['id'] . '" class="btn btn-success btn-sm float-end hidden-btn">Export CSV</a>';
        }

        echo '<form action="PR/pr-submit.php" method="POST" class="d-inline">';
        if ($pr['status'] == 0) {
            echo '<button type="submit" name="delete_pr" value="' . $pr['id'] . '" class="btn btn-danger btn-sm">Delete</button>';
        } elseif ($pr['status'] != 0) {
            echo '<button type="submit" name="delete_pr" value="' . $pr['id'] . '" class="btn btn-danger btn-sm hidden-btn">Delete</button>';
        }
        echo '</form>';
        echo '</div>';
        echo '</td>';
        echo '</tr>';

        $i++;
    }
} else {
    echo "<tr><td colspan='7' class='text-center'>ไม่พบรายการ</td></tr>";
}

$stmt->close();
mysqli_close($db_conn);
