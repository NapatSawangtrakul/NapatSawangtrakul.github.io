<?php
require('../db_connect.php');

if (isset($_GET['id'])) {
    $id = mysqli_real_escape_string($db_conn, $_GET['id']);
    $query = "SELECT * FROM addpr WHERE id = '$id'";
    $result = mysqli_query($db_conn, $query);

    if (mysqli_num_rows($result) == 1) {
        $pr = mysqli_fetch_assoc($result);
    } else {
        $_SESSION['message'] = "ไม่พบ PR";
        header("Location: ../pr-main.php");
        exit();
    }
} else {
    $_SESSION['message'] = "ไม่พบ PR";
    header("Location: ../pr-main.php");
    exit();
}

$prNumber = $pr['pr'];
$customerName = $pr['namecustomer'];

$filenameCustomerName = str_replace(array('\\', '/', ':', '*', '?', '"', '<', '>', '|'), '', $customerName);
$filename = "ใบราคาต้นทุนสินค้า {$prNumber} {$filenameCustomerName}.csv";

header('Content-Type: text/csv; charset=utf-8');
header('Content-Disposition: attachment; filename="' . rawurlencode($filename) . '"');

$output = fopen('php://output', 'w');

fwrite($output, "\xEF\xBB\xBF");

fputcsv($output, array('ชื่อลูกค้า', 'เบอร์โทรศัพท์ลูกค้า', 'PR', 'รหัส', 'รหัสสินค้า', 'ชื่อสินค้า', 'จำนวน(แผ่น)', 'ราคาต้นทุน(บาท)', 'วันที่บันทึก'));

$query = "
    SELECT 
        itemlistfac.id, 
        itemlistfac.pr_id, 
        itemlistfac.idpro_id, 
        itemlistfac.namepro, 
        itemlistfac.price, 
        itemlistfac.quantity, 
        addpr.date_created, 
        addpr.namecustomer, 
        addpr.phone
    FROM 
        itemlistfac
    JOIN 
        addpr ON itemlistfac.pr_id = addpr.pr
    WHERE 
        itemlistfac.pr_id = '$prNumber'
    ORDER BY 
        itemlistfac.pr_id DESC";

$query_run = mysqli_query($db_conn, $query);

$printedPRs = array();

if (mysqli_num_rows($query_run) > 0) {
    while ($row = mysqli_fetch_assoc($query_run)) {
        $dateCreated = date('d/m/Y', strtotime($row['date_created']));
        $formattedPrice = number_format($row['price'], 2, '.', '');
        
        $formattedPhone = preg_replace("/(\d{3})(\d{3})(\d{4})/", "$1-$2-$3", $row['phone']);
        
        if (!in_array($row['pr_id'], $printedPRs)) {
            fputcsv($output, array(
                $row['namecustomer'], 
                $formattedPhone,
                $row['pr_id'], 
                $row['id'], 
                $row['idpro_id'], 
                $row['namepro'], 
                $row['quantity'],
                $formattedPrice,  
                $dateCreated
            ));
            $printedPRs[] = $row['pr_id'];
        } else {
            fputcsv($output, array(
                '', 
                '',
                $row['pr_id'], 
                $row['id'], 
                $row['idpro_id'], 
                $row['namepro'], 
                $row['quantity'],
                $formattedPrice,  
                $dateCreated
            ));
        }
    }
}

fclose($output);
?>
