<?php
session_start();
require '../db_connect.php';

if (isset($_GET['id'])) {
    $id = mysqli_real_escape_string($db_conn, $_GET['id']);

    $checkStatusQuery = "SELECT status, pr FROM addpr WHERE id = ?";
    $checkStatusStmt = $db_conn->prepare($checkStatusQuery);
    $checkStatusStmt->bind_param("i", $id);
    $checkStatusStmt->execute();
    $checkStatusStmt->bind_result($currentStatus, $prNumber);
    $checkStatusStmt->fetch();
    $checkStatusStmt->close();

    if ($currentStatus == 1) {
        $updateQuery = "UPDATE addpr SET status = 3 WHERE id = ?";
        $updateStmt = $db_conn->prepare($updateQuery);
        $updateStmt->bind_param("i", $id);
        $updateStmt->execute();
        $updateStmt->close();
    }
}  

header("Location: ../pr-view.php");
exit();
?>
