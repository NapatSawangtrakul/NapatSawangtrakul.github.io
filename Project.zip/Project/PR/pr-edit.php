<?php
session_start();
require('../db_connect.php');

if (isset($_GET['id'])) {
    $id = mysqli_real_escape_string($db_conn, $_GET['id']);
    $query = "SELECT * FROM addpr WHERE id = '$id'";
    $result = mysqli_query($db_conn, $query);

    if (mysqli_num_rows($result) == 1) {
        $pr = mysqli_fetch_assoc($result);

        $itemListQuery = "SELECT * FROM itemlist WHERE pr_id = ?";
        $itemListStmt = $db_conn->prepare($itemListQuery);
        $itemListStmt->bind_param("s", $pr['pr']);

        if ($itemListStmt->execute()) {
            $itemListResult = $itemListStmt->get_result();

            if ($itemListResult) {
                if ($_SERVER["REQUEST_METHOD"] == "POST") {
                    $escapedQuantities = array_map(function ($quantity) use ($db_conn) {
                        return mysqli_real_escape_string($db_conn, $quantity);
                    }, $_POST['quantity']);

                    foreach ($escapedQuantities as $idpro_id => $quantity) {
                        $updateQuery = "UPDATE itemlist SET quantity = '$quantity' WHERE pr_id = '{$pr['pr']}' AND idpro_id = '$idpro_id'";
                        $updateResult = mysqli_query($db_conn, $updateQuery);

                        if (!$updateResult) {
                            echo "Error updating quantity: " . mysqli_error($db_conn);
                            exit();
                        }
                    }

                    $_SESSION['message'] = "ปรับปรุงสำเร็จ";
                    header("Location: pr-view.php?id=$id");
                    exit();
                }
?>
<!doctype html>
<html lang="th">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/factory.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <title>แก้ไขรายละเอียดใบสั่งซื้อของลูกค้า</title>
</head>

<body>
    <div class="container-fluid mt-4 custom-container">
        <?php include('../message.php'); ?>

        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <h4>แก้ไขรายละเอียดใบสั่งซื้อของลูกค้า
                            <a href="../pr-main.php" class="btn btn-danger float-end">กลับหน้าหลัก</a>
                        </h4>
                    </div>
                    <div class="card-body">
                        <?php
                        $query = mysqli_query($db_conn, "SELECT * FROM mf");
                        while ($row = mysqli_fetch_array($query)) {
                        ?>
                        <div class="form">
                            <table class="table">
                                <tr>
                                    <td>
                                        <h3><?php echo $row['nameTH']; ?></h3>
                                        <h3><?php echo $row['nameEN']; ?></h3>
                                        <h5><?php echo $row['locationTH']; ?></h5>
                                        <h5><?php echo $row['locationEN']; ?></h5>
                                        <h5>Tel : <?php echo $row['phone']; ?></h5>
                                    </td>
                                    <td>
                                        <h3>Purchase Request</h3>
                                        <h5 class="mt-4">เลขที่เอกสาร PR : <?= $pr['pr']; ?></h5>
                                        <h5>วันที่ : <?= date('d/m/Y', strtotime($pr['date_created'])); ?></h5>
                                        <h5 for="namecustomer" class="form-label">ชื่อลูกค้า :
                                            <?= $pr['namecustomer']; ?></h5>
                                    </td>
                                </tr>
                            </table>
                        </div>
                        <?php
                        }
                        ?>
                        <form method="post" action="">
                            <table class="table table-bordered">
                                <thead>
                                    <tr class="text-center">
                                        <th>รหัสสินค้า-ชื่อสินค้า</th>
                                        <th>จำนวนสินค้า(แผ่น)</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                                    while ($item = $itemListResult->fetch_assoc()) {
                                                    ?>
                                    <tr>
                                        <td><?= $item['idpro_id']; ?> - <?= $item['namepro']; ?></td>
                                        <td class="text-center">
                                            <input class="text-center" type="number" name="quantity[<?= $item['idpro_id']; ?>]"
                                                value="<?= $item['quantity']; ?>" min="1" max="99" step="1" required
                                                oninvalid="this.setCustomValidity('ค่าต่ำสุดที่เลือกได้คือ 1 และค่าสูงสุดที่เลือกได้คือ 99')"
                                                oninput="this.setCustomValidity('')" />
                                        </td>
                                    </tr>
                                    <?php
                                                    }
                                                    ?>
                                </tbody>
                            </table>
                            <button type="submit" class="btn btn-primary">บันทึก</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <style>
    .custom-container {
        margin-left: 100px;
        margin-right: 100px;
    }
    </style>

    
</body>

</html>
<?php
            } else {
                echo "เกิดข้อผิดพลาดในการดึงข้อมูล";
            }
        } else {
            echo "เกิดข้อผิดพลาดในการดึงข้อมูล";
        }
    } else {
        $_SESSION['message'] = "ไม่พบ PR";
        header("Location: ../pr-main.php");
        exit();
    }
} else {
    $_SESSION['message'] = "ไม่พบ PR";
    header("Location: ../pr-main.php");
    exit();
}
?>