<?php
session_start();
require '../db_connect.php';

function fetchAllItemDetails($db_conn) {
    $query = "SELECT itemlistpo.*, factory.Name as namefac FROM itemlistpo LEFT JOIN factory ON itemlistpo.namefac = factory.id";
    $result = $db_conn->query($query);
    return $result->fetch_all(MYSQLI_ASSOC);
}

header('Content-Type: application/json; charset=utf-8');

$data = fetchAllItemDetails($db_conn);

if (!empty($data)) {
    echo json_encode($data, JSON_UNESCAPED_UNICODE);
} else {
    echo json_encode(['message' => 'ไม่พบข้อมูล'], JSON_UNESCAPED_UNICODE);
}

mysqli_close($db_conn);
?>
