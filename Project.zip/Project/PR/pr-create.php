<?php
require_once("../db_connect.php");
?>

<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/factory.css">
    <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.1.0/css/select2.min.css" rel="stylesheet">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/jquery@3.5.1/dist/jquery.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.1.0/js/select2.min.js"></script>
    <title>เพิ่มใบสั่งซื้อของลูกค้า</title>
</head>
<body>
    <div class="container-fluid mt-4 custom-container">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <h4>เพิ่มใบสั่งซื้อของลูกค้า
                            <a href="../pr-main.php" class="btn btn-danger float-end">กลับหน้าหลัก</a>
                        </h4>
                    </div>
                    <form method="post" action="pr-process.php" onsubmit="return validateForm();">
                        <div class="card-body">
                            <label for="namecustomer">ชื่อลูกค้า <span style="color: red;">*</span></label>
                            <input type="text" class="border border-secondary" name="namecustomer" id="namecustomer">
                            <label for="phone">เบอร์โทรศัพท์ลูกค้า <span style="color: red;">*</span></label>
                            <input type="tel" class="border border-secondary" name="phone" id="phone" pattern="[0-9]*" inputmode="numeric" maxlength="10" oninput="validateNumericInput(this)">

                            <label class="text-end" for="pr">เลขที่เอกสาร PR <span class="pr_err_msg text-danger"></span></label>
                            <input type="text" class="border border-secondary" id="pr" name="pr" value="<?php echo isset($pr) ? $pr : '' ?>" readonly>
                            <small><i>สร้างโดยอัตโนมัติเมื่อบันทึก</i></small><br><br>
                            
                            <table class="table table-striped table-bordered" id="item-list">
                                <thead>
                                    <tr class="bg-navy disabled">
                                        <th class="px-1 py-1 text-center">รหัสสินค้า-ชื่อสินค้า</th>
                                        <th class="px-1 py-1 text-center">จำนวนสินค้า(แผ่น)</th>
                                        <th class="px-1 py-1 text-center"></th>
                                    </tr>
                                </thead>
                                <tbody id="textbox-container" class="text-center align-middle">
                                    <tr class="textbox-group">
                                        <td>
                                        <select name="product[]" class="form-control select2 mb-3">
    <option value="" class="text-center" <?php echo !isset($id) ? "selected" : '' ?>>-- เลือกสินค้า --</option>
    <?php 
    $sql = "SELECT * FROM product WHERE status = 1 ORDER BY idpro ASC";
    $all_product = mysqli_query($db_conn, $sql);
    while ($product = mysqli_fetch_assoc($all_product)):
    ?>
    <option value="<?php echo $product['idpro']; ?>">
        <?php echo $product['idpro'] . ' - ' . $product['namepro']; ?>
    </option>
    <?php endwhile; ?>
</select>

                                        </td>
                                        <td><input type="text" name="quantity[]" placeholder="จำนวน" class="form-control border border-secondary"></td>
                                        <td><button type="button" id="add-textbox" class="btn btn-primary">เพิ่มรายการ</button></td>
                                    </tr>
                                </tbody>
                            </table>
                            
                            <input type="submit" name="submit" class="btn btn-primary" value="บันทึก">
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
<script id="product-row-template" type="text/template">
    <tr class="textbox-group">
        <td>
        <select name="product[]" class="form-control select2 mb-3">
    <option value="" class="text-center" <?php echo !isset($id) ? "selected" : '' ?>>-- เลือกสินค้า --</option>
    <?php 
    $sql = "SELECT * FROM product WHERE status = 1 ORDER BY idpro ASC";
    $all_product = mysqli_query($db_conn, $sql);
    while ($product = mysqli_fetch_assoc($all_product)):
    ?>
    <option value="<?php echo $product['idpro']; ?>">
        <?php echo $product['idpro'] . ' - ' . $product['namepro']; ?>
    </option>
    <?php endwhile; ?>
</select>

        </td>
        <td><input type="text" name="quantity[]" placeholder="จำนวน" class="form-control mb-3 border border-secondary"></td>
        <td><button type="button" class="remove-textbox btn btn-danger btn-sm">ลบรายการ</button></td>
    </tr>
</script>

<script>
    $(document).ready(function() {
        $('.select2').select2({
            placeholder: "กรุณาเลือกสินค้า",
            allowClear: true,
            width: '100%'
        });

        var template = document.getElementById('product-row-template').innerHTML;
        var container = document.getElementById('textbox-container');

        document.getElementById('add-textbox').addEventListener('click', function () {
            var textboxGroup = document.createElement('tr');
            textboxGroup.classList.add('textbox-group');
            textboxGroup.innerHTML = template;

            var selectbox = textboxGroup.querySelector('.select2');
            var removeButton = textboxGroup.querySelector('.remove-textbox');

            $(selectbox).select2({
                placeholder: "กรุณาเลือกสินค้า",
                allowClear: true,
                width: '100%'
            });

            removeButton.addEventListener('click', function() {
                container.removeChild(textboxGroup);
            });

            container.appendChild(textboxGroup);
        });

        container.addEventListener('click', function(event) {
            if (event.target && event.target.classList.contains('remove-textbox')) {
                var textboxGroup = event.target.closest('.textbox-group');
                container.removeChild(textboxGroup);
            }
        });
    });

    function validateNumericInput(input) {
        input.value = input.value.replace(/[^0-9]/g, '').slice(0, 10);
    }

    function validateForm() {
        var namecustomer = document.getElementById("namecustomer").value;
        var phonecustomer = document.getElementById("phone").value;
        var products = document.querySelectorAll("select[name='product[]']");
        var quantities = document.querySelectorAll("input[name='quantity[]']");
        
        if (namecustomer === "") {
            alert("กรุณากรอกชื่อลูกค้า");
            return false;
        }

        if (phonecustomer === "") {
            alert("กรุณากรอกเบอร์โทรศัพท์ลูกค้า");
            return false;
        }

        for (var i = 0; i < products.length; i++) {
            var selectedProduct = products[i].value;
            var quantity = quantities[i].value;

            if (selectedProduct === "" || quantity === "") {
                alert("กรุณาเลือกรหัสสินค้าและกรอกจำนวนให้ครบทุกรายการ");
                return false;
            }
        }

        return true;
    }
</script>
<style>
    .custom-container {
        margin-left: 100px;
        margin-right: 100px;
    }

    form input[type="text"], 
    form textarea, 
    form input[type="password"], 
    form input[type="tel"] {
        font-family: "Arial", sans-serif;
        color: #000000;
        padding: 10px;
        margin: 10px;
        border: none;
        box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.2);
        border-radius: 5px;
    }
    
    th.textcss {
        text-align: center;
    }
</style>
</body>
</html>
