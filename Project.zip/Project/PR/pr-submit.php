<?php
session_start();
require '../db_connect.php';

if(isset($_POST['delete_pr'])) 
{
    $prIdToDelete = mysqli_real_escape_string($db_conn, $_POST['delete_pr']);

    $updateStatusSql = "UPDATE addpr SET status = 2 WHERE id = ?";
    $updateStatusStmt = $db_conn->prepare($updateStatusSql);

    if ($updateStatusStmt) {
        $updateStatusStmt->bind_param("i", $prIdToDelete);
        $updateStatusStmt->execute();
        $updateStatusStmt->close();

        $_SESSION['message'] = "ปรับปรุงสำเร็จ";
        header("Location: ../pr-main.php");
        exit(0);
    } else {
        $_SESSION['message'] = "ปรับปรุงไม่สำเร็จ";
        header("Location: ../pr-main.php");
        exit(0);
    }
}

$db_conn->close();
?>