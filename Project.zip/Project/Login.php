<?php
session_start();
require_once("db_connect.php");

function redirect($url) {
    header("Location: $url");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $myuserid = $_POST['userid'] ?? '';
    $mypassword = $_POST['password'] ?? '';

    if (!empty($myuserid) && !empty($mypassword)) {
        $stmt = $db_conn->prepare("SELECT * FROM login WHERE user_id = ? LIMIT 1");
        $stmt->bind_param("s", $myuserid);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows === 1) {
            $row = $result->fetch_assoc();
            $stored_password = $row['password'];

            if (password_verify($mypassword, $stored_password)) {
                $_SESSION['id'] = $row['id'];
                $_SESSION['username'] = $row['name'];
                $_SESSION['user_type'] = $row['user'];

                if ($row['status'] === 0) {
                    $redirect_url = ($row['user'] === 'A') ? 'user-main.php' : 'main_menu.php';
                    redirect($redirect_url);
                } 
            } else {
                echo "<script>
                        document.addEventListener('DOMContentLoaded', function() {
                            var myModal = new bootstrap.Modal(document.getElementById('alertModal'));
                            document.getElementById('alertMessage').innerText = 'รหัสผ่านของท่านไม่ถูกต้อง';
                            myModal.show();
                        });
                      </script>";
            }
        } else {
            echo "<script>
                    document.addEventListener('DOMContentLoaded', function() {
                        var myModal = new bootstrap.Modal(document.getElementById('alertModal'));
                        document.getElementById('alertMessage').innerText = 'ชื่อผู้ใช้หรือรหัสผ่านไม่ถูกต้อง';
                        myModal.show();
                    });
                  </script>";
        }

        $stmt->close();
    } else {
        echo "<script>
                document.addEventListener('DOMContentLoaded', function() {
                    var myModal = new bootstrap.Modal(document.getElementById('alertModal'));
                    document.getElementById('alertMessage').innerText = 'กรุณากรอกข้อมูลให้ครบถ้วน';
                    myModal.show();
                });
              </script>";
    }
}

$db_conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <title>Login</title>
</head>
<body>
    <div class="modal fade" id="alertModal" tabindex="-1" aria-labelledby="alertModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="alertModalLabel">แจ้งเตือน</h5>
                </div>
                <div class="modal-body">
                    <p id="alertMessage"></p>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-primary" id="closeModalButton">ตกลง</button>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            var alertModal = document.getElementById('alertModal');
            var closeModalButton = document.getElementById('closeModalButton');

            alertModal.addEventListener('hidden.bs.modal', function () {
                window.location.href = 'login.html';
            });

            closeModalButton.addEventListener('click', function() {
                var modal = bootstrap.Modal.getInstance(alertModal);
                modal.hide();
                window.location.href = 'login.html';
            });
        });
    </script>
</body>
</html>
