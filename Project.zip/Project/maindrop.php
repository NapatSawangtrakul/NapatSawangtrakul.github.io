<?php
session_start();
?>

<!DOCTYPE html>
<html lang="en" dir="ltr">
<head>
  <meta charset="utf-8">
  <title>M&F Shop</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css"/>
  <link rel="stylesheet" href="css/bootstrap.min.css"/>
</head>
<body>
<aside>
    <div class="main_">
      <?php if ($_SESSION['user_type'] != 'S') : ?>
        <a href="main_menu.php">เมนูหลัก</a>
        <a href="pr-main.php">จัดการใบสั่งซื้อของลูกค้า</a>
        <a href="prfac-main.php">จัดการใบต้นทุน</a>
        <a href="po-main.php">จัดการใบสั่งซื้อของโรงงาน</a>
        <p><a href="report.php">จัดทำรายงาน</a></p>
        <a href="factory-main.php">จัดการโรงงาน</a>
        <a href="product-main.php">จัดการสินค้า</a>
      <?php endif; ?>
      <?php if ($_SESSION['user_type'] == 'S') : ?>
        <a href="main_menu.php">เมนูหลัก</a>
        <p><a href="pr-main.php">จัดการใบสั่งซื้อของลูกค้า</a></p>
      <?php endif; ?>
      <p><a href="User/user-edit.php?id=<?php echo $_SESSION['id']; ?>">อัปเดตผู้ใช้งาน</a></p>
      <a href="logout.php">ออกจากระบบ</a>
      
    </div> 
  </aside>

  <script>
    var dropdown = document.getElementsByClassName("dropdown-btn");
    var i;

    for (i = 0; i < dropdown.length; i++) {
      dropdown[i].addEventListener("click", function() {
        this.classList.toggle("active");
        var dropdownContent = this.nextElementSibling;
        if (dropdownContent.style.display === "block") {
          dropdownContent.style.display = "none";
        } else {
          dropdownContent.style.display = "block";
        }
      });
    }
  </script>

  <style>
    .main_ {
      font-size: 20px; 
      padding: 0px 10px;
    }

    .main_ .active {
      width: 200px; 
    }

    .main_ a:hover, .dropdown-btn:hover {
      color: #0d0d0d;
    }

    .main_ {
      height: 100%;
      width: 200px;
      position: fixed;
      z-index: 1;
      top: 0;
      left: 0;
      background-color: #FFFFFF;
      overflow-x: hidden;
      padding-top: 20px;
      border: 1px solid black;
    }

    .main_ a {
      text-decoration: none;
      font-size: 14px;
      font-weight: 500;
      padding: 8px 0;
      display: block;
      text-align: center;
      transition: color 0.3s ease;
      color: #050505;
      border: none;
      background: none;
      width: 100%;
      cursor: pointer;
      outline: none;
    }
  </style>
</body>
</html>
