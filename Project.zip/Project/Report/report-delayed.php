<?php
session_start();
require '../db_connect.php';
date_default_timezone_set('Asia/Bangkok');
$reportDate = date('d/m/Y');

if ($db_conn->connect_error) {
    die("Connection failed: " . $db_conn->connect_error);
}
$sql = "SELECT * FROM addpo 
        JOIN itemlistpo ON addpo.po = itemlistpo.po_id 
        WHERE addpo.status = 1 OR addpo.status = 3 AND itemlistpo.status = 0 
        ORDER BY addpo.po";

$result = $db_conn->query($sql);

if ($result->num_rows > 0) {
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="../css/factory.css">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/html2canvas/1.4.1/html2canvas.min.js"></script>
    <title>รายงานสินค้าค้างรับ</title>
    <style>
    @media print {
        .print-hidden { display: none; }
    }
    .container { margin-top: 20px; }
    .card { margin-bottom: 20px; }
    .card-header { padding: 15px; }
    .card-body { padding: 20px; font-size: 16px; }
    table { width: 100%; }
    th, td { max-width: 150px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
    th:nth-child(1), td:nth-child(1) { max-width: 80px; }
    th:nth-child(2), td:nth-child(2) { max-width: 80px; }
    th:nth-child(3), td:nth-child(3) { max-width: 300px; }
    th:nth-child(5), td:nth-child(5) { max-width: 80px; }
    .print-button { margin-top: 15px; }
    .custom-container { margin-left: 100px; margin-right: 100px; }
    
    </style>
</head>

<body>
    <div class="container-fluid mt-4 custom-container">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header print-hidden">
                        <h4>รายงานสินค้าค้างรับ
                            <a href="../report.php" class="btn btn-danger float-end">กลับหน้าหลัก</a>
                            <button class="btn btn-success float-end" onclick="generatePDF()">ดาวน์โหลด PDF</button>
                        </h4>
                    </div>
                    <div class="card-body" id="print-content">
                    <table>
                        <tr class="text-center">
                            <th><label>บริษัทเอ็มแอนด์เอฟ เซ็นเตอร์ จำกัด</label></th>
                        </tr>
                        <tr class="text-center">
                            <th><label>รายงานสินค้าค้างรับ</label></th>
                        </tr>
                        <tr>
                            <th><label><?php echo "รายงานออกวันที่: $reportDate"; ?></label></th>
                        </tr>
                    </table>

                        <table border="1" class="table table-bordered"> 
                                <tr class="text-center">
                                    <th>เลขที่เอกสาร PR</th>
                                    <th>เลขที่เอกสาร PO</th>
                                    <th>ชื่อโรงงาน</th>
                                    <th>รหัสสินค้า-ชื่อสินค้า</th>
                                    <th>จำนวนสินค้า(แผ่น)</th>
                                </tr>
                                <?php
                    while ($row = $result->fetch_assoc()) {
                        $factoryNameQuery = "SELECT Name FROM factory WHERE id = " . $row["namefac"];
                        $factoryNameResult = $db_conn->query($factoryNameQuery);
                        $factoryName = $factoryNameResult->fetch_assoc()["Name"];
                
                        echo '<tr>';
                        echo '<td>' . $row["pr_id"] . '</td>';
                        echo '<td>' . $row["po_id"] . '</td>';
                        echo '<td>' . $factoryName . '</td>';  
                        echo '<td>' . $row["idpro_id"] . " - " .$row["namepro"] .'</td>';
                        echo '<td>' . $row["quantity"] . '</td>';
                        echo '</tr>';
                    }
                    ?>
                        </table>

                    </div>
                </div>
            </div>
        </div>
    </div>
    <script>
    async function generatePDF() {
        var {
            jsPDF
        } = window.jspdf;
        var content = document.getElementById('print-content');

        await html2canvas(content, {
            scale: 2
        }).then((canvas) => {
            var imgData = canvas.toDataURL('image/png');
            var pdf = new jsPDF('p', 'pt', 'a4');
            var imgWidth = 595.28;
            var pageHeight = 841.89;
            var imgHeight = canvas.height * imgWidth / canvas.width;
            var heightLeft = imgHeight;

            var position = 0;

            pdf.addImage(imgData, 'PNG', 0, position, imgWidth, imgHeight);
            heightLeft -= pageHeight;

            while (heightLeft >= 0) {
                position = heightLeft - imgHeight;
                pdf.addPage();
                pdf.addImage(imgData, 'PNG', 0, position, imgWidth, imgHeight);
                heightLeft -= pageHeight;
            }

            pdf.save('รายงานสินค้าค้างรับ.pdf');
        });
    }
    </script>
</body>
</html>
<?php
} else {
    echo "ไม่พบสินค้าค้างรับ";
    header("Location: ../report.php");
}

$db_conn->close();
?>