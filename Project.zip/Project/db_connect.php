<?php
$db_host = "localhost";
$db_user = "root";
$db_password = "";
$db_name = "project";

$db_conn = new mysqli($db_host,$db_user,$db_password,$db_name);

$sql = "SELECT * FROM `product` ORDER BY BINARY `idpro` ASC";
$all_product = mysqli_query($db_conn, $sql);

mysqli_set_charset($db_conn, "utf8");

if($db_conn->connect_error){
	die ("DB connecttion Failed !!" . $db_conn->connect_error);
}
?>