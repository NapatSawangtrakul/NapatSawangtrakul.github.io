<?php
require '../db_connect.php';

if (isset($_POST['active_product'])) {
    $idpro = mysqli_real_escape_string($db_conn, $_POST['active_product']);

    $query = "UPDATE product SET status='1' WHERE idpro='$idpro'";
    $query_run = mysqli_query($db_conn, $query);

    if ($query_run) {
        $_SESSION['message'] = "ปรับปรุงสำเร็จ";
        header("Location: ../product-main.php");
        exit(0);
    } else {
        $_SESSION['message'] = "ปรับปรุงไม่สำเร็จ";
        header("Location: ../product-main.php");
        exit(0);
    }
}

if (isset($_POST['delete_product'])) {
    $idpro = mysqli_real_escape_string($db_conn, $_POST['delete_product']);

    $query = "UPDATE product SET status='0' WHERE idpro='$idpro'";
    $query_run = mysqli_query($db_conn, $query);

    if ($query_run) {
        $_SESSION['message'] = "ปรับปรุงสำเร็จ";
        header("Location: ../product-main.php");
        exit(0);
    } else {
        $_SESSION['message'] = "ปรับปรุงไม่สำเร็จ";
        header("Location: ../product-main.php");
        exit(0);
    }
}
?>
