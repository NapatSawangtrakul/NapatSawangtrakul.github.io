<?php
session_start();
require('../db_connect.php');

$idpro = $_GET['idpro'] ?? '';
$status = $_GET['status'] ?? '';

$condition = "1";  
if (!empty($idpro)) {
    $condition .= " AND (idpro LIKE ? OR namepro LIKE ?)";
}

if ($status !== '') {
    $condition .= " AND status = ?";
}

$results_per_page = 10;

if (!isset($_GET['page'])) {
    $page = 1;
} else {
    $page = $_GET['page'];
}

$this_page_first_result = ($page - 1) * $results_per_page;

$query = "SELECT * FROM product WHERE $condition ORDER BY 
            SUBSTRING_INDEX(idpro, '-', 1) ASC, 
            CAST(SUBSTRING_INDEX(SUBSTRING_INDEX(idpro, '-', -2), '-', 1) AS UNSIGNED) ASC, 
            CAST(SUBSTRING_INDEX(idpro, '-', -1) AS DECIMAL(10, 2)) ASC, 
            idpro ASC 
          LIMIT ?, ?";
$stmt = $db_conn->prepare($query);

$params = [];
$types = '';

if (!empty($idpro)) {
    $params[] = "%$idpro%";
    $params[] = "%$idpro%";
    $types .= 'ss';
}

if ($status !== '') {
    $params[] = $status;
    $types .= 's';
}

$params[] = $this_page_first_result;
$params[] = $results_per_page;
$types .= 'ii';

$stmt->bind_param($types, ...$params);

$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    while ($product = $result->fetch_assoc()) {
        echo '<tr class="align-middle">';
        echo '<td>' . $product['idpro'] . '</td>';
        echo '<td>' . $product['namepro'] . '</td>';
        echo '<td class="text-center align-middle">';
        echo '<div class="d-flex align-items-center">';
        echo '<a href="./Product/product-edit.php?idpro=' . $product['idpro'] . '" class="btn btn-success btn-sm">Edit</a>';

        if ($product['status'] == 0) {
            echo '<form action="product-submit.php" method="POST" class="d-inline">';
            echo '<button type="submit" name="active_product" value="' . $product['idpro'] . '" class="btn btn-danger btn-sm">Delete</button>';
            echo '</form>';
        } else {
            echo '<form action="product-submit.php" method="POST" class="d-inline">';
            echo '<button type="submit" name="active_product" value="' . $product['idpro'] . '" class="btn btn-danger btn-sm hidden-btn">Delete</button>';
            echo '</form>';
        }

        if ($product['status'] == 0) {
            echo '<form action="product-submit.php" method="POST" class="d-inline">';
            echo '<button type="submit" name="delete_product" value="' . $product['idpro'] . '" class="btn btn-danger btn-sm hidden-btn">Delete</button>';
            echo '</form>';
        } else {
            echo '<form action="product-submit.php" method="POST" class="d-inline">';
            echo '<button type="submit" name="delete_product" value="' . $product['idpro'] . '" class="btn btn-danger btn-sm">Delete</button>';
            echo '</form>';
        }

        echo '</div>';
        echo '</td>';
        echo '</tr>';
    }
} else {
    echo "<tr><td colspan='3' class='text-center'>ไม่พบรายการ</td></tr>";
}

$stmt->close();
mysqli_close($db_conn);
?>
