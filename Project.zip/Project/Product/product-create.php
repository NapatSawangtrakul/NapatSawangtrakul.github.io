<?php
require '../db_connect.php';

if (isset($_POST['save_product'])) {
    $idpro = mysqli_real_escape_string($db_conn, $_POST['idpro']);
    $namepro = mysqli_real_escape_string($db_conn, $_POST['namepro']);

    $query = "INSERT INTO product (idpro, namepro) VALUES ('$idpro', '$namepro')";
    $query_run = mysqli_query($db_conn, $query);

    if ($query_run) {
        $_SESSION['message'] = "เพิ่มสินค้าสำเร็จ";
        header("Location: ../product-main.php");
        exit(0);
    } else {
        $_SESSION['message'] = "เพิ่มสินค้าไม่สำเร็จ";
        header("Location: ../product-main.php");
        exit(0);
    }
}
?>

<!doctype html>
<html lang="th">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/factory.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <title>เพิ่มสินค้า</title>
</head>
<body>
<div class="container-fluid mt-4 custom-container">
        <div class="row">
            <div class="col-md-8 mx-auto">
                <div class="card">
                    <div class="card-header">
                        <h4>เพิ่มสินค้า 
                            <a href="../product-main.php" class="btn btn-danger float-end">กลับหน้าหลัก</a>
                        </h4>
                    </div>
                    <div class="card-body">
                        <form action="product-create.php" method="POST">
                            <div class="mb-3">
                                <label>รหัสสินค้า <span style="color: red;">*</span></label>
                                <input type="text" name="idpro" class="form-control border border-secondary" required>
                            </div>
                            <div class="mb-3">
                                <label>ชื่อสินค้า <span style="color: red;">*</span></label>
                                <input type="text" name="namepro" class="form-control border border-secondary" required>
                            </div>
                            <div class="mb-3">
                                <button type="submit" name="save_product" class="btn btn-primary">บันทึก</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
