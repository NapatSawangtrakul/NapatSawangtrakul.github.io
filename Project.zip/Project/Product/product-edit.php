<?php
require '../db_connect.php';

if (isset($_GET['idpro'])) {
    $idpro = mysqli_real_escape_string($db_conn, $_GET['idpro']);
    $query = "SELECT * FROM product WHERE idpro='$idpro'";
    $query_run = mysqli_query($db_conn, $query);

    if (mysqli_num_rows($query_run) > 0) {
        $product = mysqli_fetch_array($query_run);
    } else {
        $_SESSION['message'] = "ไม่พบสินค้า";
        header("Location: ../product-main.php");
        exit(0);
    }
}

if (isset($_POST['update_product'])) {
    $new_idpro = mysqli_real_escape_string($db_conn, $_POST['idpro']);
    $namepro = mysqli_real_escape_string($db_conn, $_POST['namepro']);
    
    $query = "UPDATE product SET idpro='$new_idpro', namepro='$namepro' WHERE idpro='$idpro'";
    $query_run = mysqli_query($db_conn, $query);

    if ($query_run) {
        $_SESSION['message'] = "ปรับปรุงสินค้าสำเร็จ";
        header("Location: ../product-main.php");
        exit(0);
    } else {
        $_SESSION['message'] = "ปรับปรุงสินค้าไม่สำเร็จ";
        header("Location: Product-edit.php?idpro=" . $idpro);
        exit(0);
    }
}
?>

<!doctype html>
<html lang="th">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/factory.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <title>แก้ไขสินค้า</title>
</head>
<body>
<div class="container-fluid mt-4 custom-container">
        <div class="row">
            <div class="col-md-8 mx-auto">
                <div class="card">
                    <div class="card-header">
                        <h4>แก้ไขสินค้า 
                            <a href="../product-main.php" class="btn btn-danger float-end">กลับหน้าหลัก</a>
                        </h4>
                    </div>
                    <div class="card-body">
                        <form action="product-edit.php?idpro=<?= $product['idpro']; ?>" method="POST">
                            <div class="mb-3">
                                <label>รหัสสินค้า</label>
                                <input type="text" name="idpro" value="<?= $product['idpro']; ?>" class="form-control border border-secondary" required>
                            </div>
                            <div class="mb-3">
                                <label>ชื่อสินค้า</label>
                                <input type="text" name="namepro" value="<?= $product['namepro']; ?>" class="form-control border border-secondary" required>
                            </div>
                            <div class="mb-3">
                                <button type="submit" name="update_product" class="btn btn-primary">บันทึก</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
