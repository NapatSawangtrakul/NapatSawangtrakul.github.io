<?php
session_start();
require('../db_connect.php');
?>

<!DOCTYPE html>
<html lang="th">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/price.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <title>เพิ่มราคาใบต้นทุน</title>
</head>

<body>
    <div class="container-fluid mt-4 custom-container">
        <?php include('../message.php'); ?>
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <h4>เพิ่มราคาใบต้นทุน
                            <a href="../prfac-main.php" class="btn btn-danger float-end">กลับหน้าหลัก</a>
                        </h4>
                    </div>
                    <form id="priceForm" method="post" onsubmit="return false;">
                        <div class="card-body">
                            <?php
                            $query = mysqli_query($db_conn, "SELECT * FROM mf");

                            while ($row = mysqli_fetch_array($query)) {
                            ?>
                            <div class="form">
                                <table class="table">
                                    <tr>
                                        <td>
                                            <h3><?php echo htmlspecialchars($row['nameTH']); ?></h3>
                                            <h3><?php echo htmlspecialchars($row['nameEN']); ?></h3>
                                            <h5><?php echo htmlspecialchars($row['locationTH']); ?></h5>
                                            <h5><?php echo htmlspecialchars($row['locationEN']); ?></h5>
                                            <h5>Tel : <?php echo htmlspecialchars($row['phone']); ?></h5>
                                        </td>
                                        <td>
                                            <h3>Purchase Request</h3>
                                            <h5>
                                                <select name="pr_select" id="pr_select" class="form-select">
                                                    <option value="" selected>เลือกใบสั่งซื้อที่ต้องการเพิ่มราคาสินค้า</option>
                                                    <?php
                                                        $prListQuery = "SELECT DISTINCT pr FROM addpr";
                                                        $prListResult = mysqli_query($db_conn, $prListQuery);
                                                        if ($prListResult) {
                                                            while ($row = mysqli_fetch_assoc($prListResult)) {
                                                                $prValue = htmlspecialchars($row['pr']);
        
                                                                $checkPriceQuery = "SELECT COUNT(*) as price_count FROM itemlistfac WHERE pr_id = ? AND (price IS NULL OR price = '')";
                                                                $stmt = $db_conn->prepare($checkPriceQuery);
                                                                $stmt->bind_param("s", $prValue);
                                                                $stmt->execute();
                                                                $checkPriceResult = $stmt->get_result();
                                                                $priceCount = $checkPriceResult->fetch_assoc()['price_count'];

                                                                if ($priceCount > 0) {
                                                    ?>
                                                                    <option value="<?= $prValue ?>"><?= $prValue ?></option>
                                                    <?php
                                                                }
                                                            }
                                                        }
                                                    ?>
                                                </select>
                                            </h5>
                                            <h5 id="date_value">วันที่: </h5>
                                            <h5 id="customer_value">ชื่อลูกค้า: </h5>
                                        </td>
                                    </tr>
                                </table>
                            </div>
                            <?php
                            }
                            ?>
                            <table class="table table-bordered">
                                <thead>
                                    <tr class="text-center align-middle">
                                        <th>รหัสสินค้า-ชื่อสินค้า</th>
                                        <th>จำนวนสินค้า(แผ่น)</th>
                                        <th>ราคาสินค้าต่อหน่วย(บาท)</th>
                                    </tr>
                                </thead>
                                <tbody id="item_list_body">
                                </tbody>
                            </table>
                            <button type="button" class="btn btn-success" id="insertButton">บันทึกราคา</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <script>
    document.addEventListener("DOMContentLoaded", function() {
        const prSelect = document.getElementById("pr_select");
        const dateElement = document.getElementById("date_value");
        const customerElement = document.getElementById("customer_value");
        const itemListBody = document.getElementById("item_list_body");
        const insertButton = document.getElementById("insertButton");

        prSelect.addEventListener("change", function() {
            const selectedPR = prSelect.value;

            if (selectedPR) {
                fetch(`prfacget-pr-data.php?pr_value=${selectedPR}`)
                    .then(response => response.json())
                    .then(data => {
                        dateElement.textContent = data.date_created ? "วันที่: " + new Date(data
                            .date_created).toLocaleDateString('en-GB') : "ไม่พบวันที่";
                        customerElement.textContent = data.namecustomer ? "ชื่อลูกค้า: " + data
                            .namecustomer : "ไม่พบชื่อลูกค้า";

                        itemListBody.innerHTML = '';
                        if (data.items.length > 0) {
                            data.items.forEach(function(item) {
                                const row = document.createElement('tr');
                                row.innerHTML = `
                                    <td style="display: none">${item.namefac}</td>
                                    <td style="display: none">${item.pr_id}</td>
                                    <td>${item.idpro_id} - ${item.namepro}</td>
                                    <td class="text-center align-middle">${item.quantity}</td>
                                    <td class="text-center align-middle" id="price_cell_${item.idpro_id}">
                                        <input class="text-end align-middle" type="text" name="price_${item.idpro_id}" data-idpro="${item.idpro_id}" value="${item.price || ''}">
                                    </td>
                                `;
                                itemListBody.appendChild(row);
                            });
                        } else {
                            itemListBody.innerHTML = '<tr><td colspan="4">ไม่พบรายการ</td></tr>';
                        }
                    })
                    .catch(error => {
                        console.error('Error:', error);
                    });
            } else {
                dateElement.textContent = "วันที่: ";
                customerElement.textContent = "ชื่อลูกค้า: ";
                itemListBody.innerHTML = '';
            }
        });

        insertButton.addEventListener("click", function() {
    const rows = itemListBody.querySelectorAll("tr");
    const insertionData = [];

    rows.forEach(row => {
        const columns = row.querySelectorAll("td");
        if (columns.length === 5) {
            const namefac = columns[0].textContent;
            const pr_id = columns[1].textContent;
            const idpro_id = columns[2].textContent.split(' - ')[0];
            const quantity = columns[3].textContent;
            const priceInput = row.querySelector("input[name^='price']");
            const price = priceInput ? priceInput.value : "";

            insertionData.push({
                namefac,
                pr_id,
                idpro_id,
                quantity,
                price
            });
        }
    });

    if (insertionData.length > 0) {
        fetch('prfacins-itemlistins.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(insertionData)
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    window.location.href = '../prfac-main.php';
                } else {
                    alert('เกิดข้อผิดพลาด: ' + (data.error || 'Unknown error'));
                }
            })
            .catch(error => {
                console.error('Error:', error);
            });
    }
});
    });
    </script>
    <style>
    .custom-container {
        margin-left: 100px;
        margin-right: 100px;
    }
    </style>
</body>

</html>