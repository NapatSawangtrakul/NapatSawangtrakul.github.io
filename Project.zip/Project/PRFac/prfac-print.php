<?php
session_start();
require '../db_connect.php';

if (isset($_GET['id']) && is_numeric($_GET['id'])) {
    $id = mysqli_real_escape_string($db_conn, $_GET['id']);

    // ดึงสถานะและชื่อโรงงานจากฐานข้อมูล
    $checkStatusQuery = "SELECT status, namefac FROM addprfac WHERE id = ?";
    $checkStatusStmt = $db_conn->prepare($checkStatusQuery);
    $checkStatusStmt->bind_param("i", $id);
    $checkStatusStmt->execute();
    $checkStatusStmt->bind_result($currentStatus, $namefac);
    $checkStatusStmt->fetch();
    $checkStatusStmt->close();

    if ($currentStatus == 0) {
        // อัพเดตสถานะเป็น 1
        $updateQuery = "UPDATE addprfac SET status = '1' WHERE id = ?";
        $updateStmt = $db_conn->prepare($updateQuery);
        $updateStmt->bind_param("i", $id);
        $updateStmt->execute();
        $updateStmt->close();

        // ดึง LineToken ของโรงงาน
        $lineTokenQuery = "SELECT LineToken FROM factory WHERE id = ?";
        $lineTokenStmt = $db_conn->prepare($lineTokenQuery);
        $lineTokenStmt->bind_param("i", $namefac);
        $lineTokenStmt->execute();
        $lineTokenStmt->bind_result($lineToken);
        $lineTokenStmt->fetch();
        $lineTokenStmt->close();

        // ตรวจสอบว่า LineToken มีค่าหรือไม่
        if ($lineToken) {
            // สร้างข้อความแจ้งเตือน
            $sMessage = "มีใบขอให้เสนอราคามาใหม่ PR ID: " . $id;

            // ส่งข้อความไปยัง Line Notify
            $chOne = curl_init(); 
            curl_setopt($chOne, CURLOPT_URL, "https://notify-api.line.me/api/notify"); 
            curl_setopt($chOne, CURLOPT_SSL_VERIFYHOST, 2); 
            curl_setopt($chOne, CURLOPT_SSL_VERIFYPEER, 1); 
            curl_setopt($chOne, CURLOPT_POST, 1); 
            curl_setopt($chOne, CURLOPT_POSTFIELDS, "message=" . urlencode($sMessage)); 
            $headers = array(
                'Content-type: application/x-www-form-urlencoded', 
                'Authorization: Bearer ' . $lineToken,
            );
            curl_setopt($chOne, CURLOPT_HTTPHEADER, $headers); 
            curl_setopt($chOne, CURLOPT_RETURNTRANSFER, 1); 
            $result = curl_exec($chOne);

            // ตรวจสอบว่า curl ทำงานสำเร็จหรือไม่
            if ($result === false) {
                $_SESSION['message'] = "Error sending message to Line: " . curl_error($chOne);
            } else {
                $_SESSION['message'] = "ส่งข้อความ Line สำเร็จ!";
            }
            curl_close($chOne);
        } else {
            $_SESSION['message'] = "ไม่พบ LineToken สำหรับโรงงานนี้";
        }
    } else {
        $_SESSION['message'] = "สถานะไม่ถูกต้อง (ไม่สามารถอัพเดตได้)";
    }
} else {
    $_SESSION['message'] = "ไม่พบ PR หรือ PR ID ไม่ถูกต้อง";
}

// เปลี่ยนเส้นทางไปหน้าจอแสดงผล
header("Location: ../prfac-view.php");
exit();
?>
