<?php
session_start();
require '../db_connect.php';

if (isset($_POST['delete_prfac'])) {
    $prfac_id = mysqli_real_escape_string($db_conn, $_POST['delete_prfac']);

    $deleteQuery = "UPDATE addprfac SET status = 3 WHERE id = ?";
    $stmt = mysqli_prepare($db_conn, $deleteQuery);
    mysqli_stmt_bind_param($stmt, "i", $prfac_id);
    
    if (mysqli_stmt_execute($stmt)) {
        $_SESSION['message'] = "ปรับปรุงสำเร็จ";
    } else {
        $_SESSION['message'] = "ปรับปรุงไม่สำเร็จ";
    }
    
    mysqli_stmt_close($stmt);
}

header("Location: ../prfac-main.php");
exit();
?>
