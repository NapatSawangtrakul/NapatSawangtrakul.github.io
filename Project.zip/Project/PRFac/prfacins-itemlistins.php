<?php
session_start();
require('../db_connect.php');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $insertionData = json_decode(file_get_contents('php://input'), true);
    $response = ['success' => true];
    $lastUpdatedPR = null;

    foreach ($insertionData as $record) {
        $namefac = mysqli_real_escape_string($db_conn, $record['namefac']);
        $pr_id = mysqli_real_escape_string($db_conn, $record['pr_id']);
        $idpro_id = mysqli_real_escape_string($db_conn, $record['idpro_id']);
        $price = isset($record['price']) && is_numeric($record['price']) ? (float) $record['price'] : null;

        if ($price !== null && ($price < 1 || $price > 100000)) {
            $response = ['success' => false, 'error' => 'ราคาสินค้าต้องอยู่ในช่วง 1 ถึง 100000'];
            echo json_encode($response);
            exit;
        }

        $checkExistingQuery = "SELECT COUNT(*) as existing_count FROM itemlistfac WHERE pr_id = ? AND idpro_id = ?";
        $checkExistingStmt = mysqli_prepare($db_conn, $checkExistingQuery);
        mysqli_stmt_bind_param($checkExistingStmt, "ss", $pr_id, $idpro_id);
        mysqli_stmt_execute($checkExistingStmt);
        $existingResult = mysqli_stmt_get_result($checkExistingStmt);
        $existingCount = mysqli_fetch_assoc($existingResult)['existing_count'];
        
        if ($existingCount > 0) {
            $updateQuery = "UPDATE itemlistfac SET price = ? WHERE pr_id = ? AND idpro_id = ? AND namefac = ?";
            $updateStmt = mysqli_prepare($db_conn, $updateQuery);
            mysqli_stmt_bind_param($updateStmt, "dsss", $price, $pr_id, $idpro_id, $namefac);

            if (mysqli_stmt_execute($updateStmt)) {
                mysqli_stmt_close($updateStmt);

                $checkPriceQuery = "SELECT COUNT(*) as total_items, SUM(CASE WHEN price IS NOT NULL THEN 1 ELSE 0 END) as priced_items FROM itemlistfac WHERE pr_id = ? AND namefac = ?";
                $checkPriceStmt = mysqli_prepare($db_conn, $checkPriceQuery);
                mysqli_stmt_bind_param($checkPriceStmt, "ss", $pr_id, $namefac);
                mysqli_stmt_execute($checkPriceStmt);
                $checkPriceResult = mysqli_stmt_get_result($checkPriceStmt);
                $checkPriceRow = mysqli_fetch_assoc($checkPriceResult);
                $total_items = $checkPriceRow['total_items'];
                $priced_items = $checkPriceRow['priced_items'];
                mysqli_stmt_close($checkPriceStmt);
                
                $status = ($total_items == $priced_items) ? 2 : 1;

                $updateStatusQuery = "UPDATE addprfac SET status = ? WHERE pr = ? AND namefac = ?";
                $updateStatusStmt = mysqli_prepare($db_conn, $updateStatusQuery);
                mysqli_stmt_bind_param($updateStatusStmt, "iss", $status, $pr_id, $namefac);

                if (!mysqli_stmt_execute($updateStatusStmt)) {
                    $response = ['success' => false, 'error' => 'เกิดข้อผิดพลาดในการปรับปรุง PR'];
                    error_log("เกิดข้อผิดพลาดในการปรับปรุงสถานะ addprfac : " . mysqli_error($db_conn));
                    echo json_encode($response);
                    exit;
                }
                mysqli_stmt_close($updateStatusStmt);
            } else {
                $response = ['success' => false, 'error' => 'เกิดข้อผิดพลาดในการอัปเดตข้อมูล'];
                error_log("เกิดข้อผิดพลาดในการอัปเดตข้อมูล itemlistfac: " . mysqli_error($db_conn));
                echo json_encode($response);
                exit;
            }
        } else {
            $response = ['success' => false, 'error' => 'ไม่พบข้อมูลใน itemlistfac.'];
            echo json_encode($response);
            exit;
        }

        $lastUpdatedPR = $pr_id;
    }

    $prCheckQuery = "SELECT pr_id, COUNT(*) as total_items, SUM(CASE WHEN price IS NOT NULL THEN 1 ELSE 0 END) as priced_items FROM itemlistfac GROUP BY pr_id";
    $prCheckResult = mysqli_query($db_conn, $prCheckQuery);

    while ($prRow = mysqli_fetch_assoc($prCheckResult)) {
        $pr_id = $prRow['pr_id'];
        $total_items = $prRow['total_items'];
        $priced_items = $prRow['priced_items'];

        $status = ($total_items === $priced_items) ? 4 : 3;

        $updateAddPrQuery = "UPDATE addpr SET status = ? WHERE pr = ?";
        $updateAddPrStmt = mysqli_prepare($db_conn, $updateAddPrQuery);
        mysqli_stmt_bind_param($updateAddPrStmt, "is", $status, $pr_id);

        if (!mysqli_stmt_execute($updateAddPrStmt)) {
            $response = ['success' => false, 'error' => 'เกิดข้อผิดพลาดในการอัปเดตสถาน addpr'];
            error_log("Error updating addpr status: " . mysqli_error($db_conn));
            echo json_encode($response);
            exit;
        }
        mysqli_stmt_close($updateAddPrStmt);

        if ($pr_id === $lastUpdatedPR && $status == 4) {
            $customerNameQuery = "SELECT namecustomer FROM addpr WHERE pr = ?";
            $customerNameStmt = mysqli_prepare($db_conn, $customerNameQuery);
            mysqli_stmt_bind_param($customerNameStmt, "s", $pr_id);
            mysqli_stmt_execute($customerNameStmt);
            $customerNameResult = mysqli_stmt_get_result($customerNameStmt);
            $customerNameRow = mysqli_fetch_assoc($customerNameResult);
            $customerName = $customerNameRow['namecustomer'];
            mysqli_stmt_close($customerNameStmt);

            $sToken = "oLUH5VOquqfpMrJfLmiFXpn7KHG1nl4dkhzm1fhcwnS";
            $sMessage = "ใบสั่งซื้อของลูกค้ามีราคาครบแล้ว " . $pr_id . " " . $customerName;

            $chOne = curl_init(); 
            curl_setopt($chOne, CURLOPT_URL, "https://notify-api.line.me/api/notify"); 
            curl_setopt($chOne, CURLOPT_SSL_VERIFYHOST, 0); 
            curl_setopt($chOne, CURLOPT_SSL_VERIFYPEER, 0); 
            curl_setopt($chOne, CURLOPT_POST, 1); 
            curl_setopt($chOne, CURLOPT_POSTFIELDS, "message=".$sMessage); 
            $headers = array('Content-type: application/x-www-form-urlencoded', 'Authorization: Bearer '.$sToken.'', );
            curl_setopt($chOne, CURLOPT_HTTPHEADER, $headers); 
            curl_setopt($chOne, CURLOPT_RETURNTRANSFER, 1); 
            $result = curl_exec($chOne);
            if ($result === false) {
                error_log("Error sending LINE notification: " . curl_error($chOne));
            }
            curl_close($chOne);
        }
    }

    echo json_encode($response);
} else {
    $response = ['success' => false];
    echo json_encode($response);
}
?>
