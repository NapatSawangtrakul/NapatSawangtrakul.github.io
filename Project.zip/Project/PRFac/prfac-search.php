<?php
require('../db_connect.php');

$dateFrom = $_GET['date_from'];
$dateTo = $_GET['date_to'];
$customer = $_GET['namecustomer'];
$status = $_GET['status'];

$results_per_page = 10;

if (!isset($_GET['page'])) {
    $page = 1;
} else {
    $page = $_GET['page'];
}

$this_page_first_result = ($page - 1) * $results_per_page;

$condition = "addprfac.status";  
if (!empty($dateFrom) && !empty($dateTo)) {
    $condition .= " AND addprfac.date_created BETWEEN '$dateFrom' AND '$dateTo'";
}
if (!empty($customer)) {
    $condition .= " AND (addprfac.namecustomer LIKE '%$customer%' OR addprfac.pr LIKE '%$customer%' OR factory.Name LIKE '%$customer%')"; 
}
if ($status !== '') {
    $condition .= " AND addprfac.status = $status"; 
}

$query = "SELECT addprfac.*, factory.Name AS factory_name FROM addprfac 
          LEFT JOIN factory ON addprfac.namefac = factory.id 
          WHERE $condition ORDER BY pr DESC LIMIT $this_page_first_result, $results_per_page";

$query_run = mysqli_query($db_conn, $query);

$i = 1; 
if (mysqli_num_rows($query_run) > 0) {
    while ($prfac = mysqli_fetch_assoc($query_run)) {
        echo '<tr class="align-middle">';
        echo '<td>' . $i . '</td>';
        echo '<td>' . date("d/m/Y", strtotime($prfac['date_created'])) . '</td>';
        echo '<td>' . $prfac['pr'] . '</td>';
        echo '<td>' . $prfac['namecustomer'] . '</td>';
        $phone = $prfac['phone'];
        if (strlen($phone) == 10) {
            $formattedPhone = substr($phone, 0, 3) . '-' . substr($phone, 3, 3) . '-' . substr($phone, 6);
        } else {
            $formattedPhone = $phone;
        }
        echo '<td>' . $formattedPhone . '</td>';
        echo '<td>' . $prfac['factory_name'] . '</td>';

        echo '<td class="align-middle">';
        if ($prfac['status'] == 0) {
            echo '<span style="color:#080808;">ยังไม่ดำเนินการ</span>';
        } elseif ($prfac['status'] == 1) {
            echo '<span style="color:#080808;">รอตอบกลับ</span>';
        } elseif ($prfac['status'] == 2) {
            echo '<span style="color:#080808;">ตอบกลับ</span>';
        } elseif ($prfac['status'] == 3) {
            echo '<span style="color:#080808;">ยกเลิกดำเนินการ</span>';
        }  elseif ($prfac['status'] == 4) {
            echo '<span style="color:#080808;">สั่งซื้อ</span>';
        }  elseif ($prfac['status'] == 5) {
            echo '<span style="color:#080808;">หมดอายุ</span>';
        }
        echo '</td>';

        echo '<td class="text-center align-middle">
              <div class="d-flex align-items-center">
                <a href="PRFac/prfac-view.php?id=' . $prfac['id'] . '" class="btn btn-info btn-sm">View</a>';

        if ($prfac['status'] == 2) {
            echo '<form action="PO/order-process.php" method="POST" class="d-inline">
                <button type="submit" name="Order_po" value="' . $prfac['id'] . '" class="btn btn-warning btn-sm" style="font-size: 12px">Create PO</button>
            </form>';
        } elseif ($prfac['status'] != 2) {
            echo '<form action="PO/order-process.php" method="POST" class="d-inline">
                <button type="submit" name="Order_po" value="' . $prfac['id'] . '" class="btn btn-warning btn-sm hidden-btn" style="font-size: 12px">Create PO</button>
            </form>';
        }
    
        echo '<form action="PRFac/prfac-submit.php" method="POST" class="d-inline">';
        if ($prfac['status'] == 0 || $prfac['status'] == 1) {
            echo '<button type="submit" name="delete_prfac" value="' . $prfac['id'] . '" class="btn btn-danger btn-sm">Delete</button>';
        } elseif ($prfac['status'] != 0 || $prfac['status'] != 1) {
            echo '<button type="submit" name="delete_prfac" value="' . $prfac['id'] . '" class="btn btn-danger btn-sm hidden-btn">Delete</button>';
        }
        echo '</form>';
        echo '</div>';
        echo '</td>';
        echo '</tr>';

        $i++; 
    }

    $query_count = "SELECT COUNT(*) AS total FROM addprfac";
    $query_count_run = mysqli_query($db_conn, $query_count);
    $row_count = mysqli_fetch_assoc($query_count_run);
    $total_pages = ceil($row_count["total"] / $results_per_page);

} else {
    echo "<tr><td colspan='8' class='text-center'>ไม่พบรายการ</td></tr>";
}

mysqli_close($db_conn);
?>
