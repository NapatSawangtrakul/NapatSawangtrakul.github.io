<?php
require('../db_connect.php');

if (isset($_GET['pr_value'])) {
    $selectedPR = mysqli_real_escape_string($db_conn, $_GET['pr_value']);

    $query = "SELECT date_created, namecustomer FROM addpr WHERE pr = '$selectedPR'";
    $result = mysqli_query($db_conn, $query);

    $data = array();

    if ($result && mysqli_num_rows($result) == 1) {
        $row = mysqli_fetch_assoc($result);
        $data['date_created'] = $row['date_created'];
        $data['namecustomer'] = $row['namecustomer'];
        $query = "SELECT * FROM itemlistfac WHERE pr_id = '$selectedPR'";
        $result = mysqli_query($db_conn, $query);

        $data['items'] = array(); 

        if ($result && mysqli_num_rows($result) > 0) {
            while ($row = mysqli_fetch_assoc($result)) {
                $data['items'][] = $row; 
            }
        }
    }

    echo json_encode($data); 
} else {
    echo 'ไม่พบข้อมูลที่ต้องการ';
}
?>
